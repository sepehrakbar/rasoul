// PufferFront - Technology Tree Definitions
// Multi-tier tech tree with upgrades, doctrines, and unlocks

export type TechTier = 'tier1' | 'tier2' | 'tier3' | 'tier4' | 'experimental';
export type TechType = 'unit_unlock' | 'upgrade' | 'doctrine' | 'economic' | 'military';

export interface TechCost {
  manpower: number;
  fuel: number;
  ammo: number;
  steel: number;
  researchTime: number; // seconds
}

export interface TechPrerequisite {
  techId: string;
  tier?: TechTier;
}

export interface TechEffect {
  type: string;
  value?: number;
  targetType?: string;
  stat?: string;
  duration?: number;
  description: string;
}

export interface Technology {
  id: string;
  name: string;
  description: string;
  tier: TechTier;
  type: TechType;
  cost: TechCost;
  prerequisites: TechPrerequisite[];
  effects: TechEffect[];
  unlocksUnits?: string[];
  unlocksBuildings?: string[];
  factionExclusive?: string[];
  tags: string[];
}

export const TECHNOLOGIES: Record<string, Technology> = {
  // ========== TIER 1: BASIC TECHNOLOGIES ==========
  small_arms_upgrade: {
    id: 'small_arms_upgrade',
    name: 'Small Arms Upgrade',
    description: 'Improved rifles and submachine guns for infantry.',
    tier: 'tier1',
    type: 'upgrade',
    cost: {
      manpower: 30,
      fuel: 10,
      ammo: 20,
      steel: 15,
      researchTime: 45
    },
    prerequisites: [],
    effects: [
      { type: 'damage_bonus', value: 0.1, targetType: 'infantry', stat: 'damage', description: '+10% infantry damage' }
    ],
    unlocksUnits: ['smg_trooper'],
    tags: ['tier1', 'infantry', 'upgrade']
  },

  advanced_training: {
    id: 'advanced_training',
    name: 'Advanced Training',
    description: 'Specialized combat training for elite infantry.',
    tier: 'tier1',
    type: 'military',
    cost: {
      manpower: 40,
      fuel: 5,
      ammo: 15,
      steel: 10,
      researchTime: 50
    },
    prerequisites: [],
    effects: [
      { type: 'accuracy_bonus', value: 0.1, targetType: 'infantry', stat: 'accuracy', description: '+10% infantry accuracy' }
    ],
    unlocksUnits: ['sniper'],
    tags: ['tier1', 'infantry', 'training']
  },

  engineering_corps: {
    id: 'engineering_corps',
    name: 'Engineering Corps',
    description: 'Establish combat engineer units for fortifications.',
    tier: 'tier1',
    type: 'military',
    cost: {
      manpower: 35,
      fuel: 10,
      ammo: 10,
      steel: 20,
      researchTime: 40
    },
    prerequisites: [],
    effects: [
      { type: 'construction_speed', value: 0.15, description: '+15% construction speed' }
    ],
    unlocksUnits: ['engineer'],
    unlocksBuildings: ['trench'],
    tags: ['tier1', 'support', 'engineering']
  },

  medical_corps: {
    id: 'medical_corps',
    name: 'Medical Corps',
    description: 'Field medics to keep your troops fighting.',
    tier: 'tier1',
    type: 'military',
    cost: {
      manpower: 30,
      fuel: 5,
      ammo: 10,
      steel: 10,
      researchTime: 35
    },
    prerequisites: [],
    effects: [
      { type: 'heal_rate', value: 0.2, targetType: 'infantry', description: '+20% infantry heal rate' }
    ],
    unlocksUnits: ['medic'],
    tags: ['tier1', 'support', 'medical']
  },

  officer_training: {
    id: 'officer_training',
    name: 'Officer Training',
    description: 'Train leadership officers for better unit coordination.',
    tier: 'tier1',
    type: 'military',
    cost: {
      manpower: 45,
      fuel: 10,
      ammo: 15,
      steel: 15,
      researchTime: 50
    },
    prerequisites: [],
    effects: [
      { type: 'morale_bonus', value: 0.15, description: '+15% morale for all units' }
    ],
    unlocksUnits: ['officer'],
    tags: ['tier1', 'command', 'leadership']
  },

  light_armor_doctrine: {
    id: 'light_armor_doctrine',
    name: 'Light Armor Doctrine',
    description: 'Develop light tanks for reconnaissance and fast attacks.',
    tier: 'tier1',
    type: 'doctrine',
    cost: {
      manpower: 50,
      fuel: 30,
      ammo: 20,
      steel: 40,
      researchTime: 60
    },
    prerequisites: [],
    effects: [
      { type: 'speed_bonus', value: 0.1, targetType: 'light_tank', stat: 'speed', description: '+10% light tank speed' }
    ],
    unlocksUnits: ['m3_stuart', 'panzer_ii'],
    tags: ['tier1', 'armor', 'doctrine']
  },

  industrialization: {
    id: 'industrialization',
    name: 'Industrialization',
    description: 'Build up heavy industry for vehicle production.',
    tier: 'tier1',
    type: 'economic',
    cost: {
      manpower: 60,
      fuel: 20,
      ammo: 15,
      steel: 50,
      researchTime: 70
    },
    prerequisites: [],
    effects: [
      { type: 'production_bonus', value: 0.1, targetType: 'vehicle', description: '+10% vehicle production speed' },
      { type: 'steel_production', value: 10, description: '+10 steel/min' }
    ],
    unlocksBuildings: ['vehicle_factory'],
    tags: ['tier1', 'economic', 'industry']
  },

  aviation_technology: {
    id: 'aviation_technology',
    name: 'Aviation Technology',
    description: 'Basic aircraft design and production capabilities.',
    tier: 'tier1',
    type: 'military',
    cost: {
      manpower: 50,
      fuel: 40,
      ammo: 20,
      steel: 45,
      researchTime: 65
    },
    prerequisites: [],
    effects: [
      { type: 'aircraft_speed', value: 0.08, targetType: 'aircraft', stat: 'speed', description: '+8% aircraft speed' }
    ],
    unlocksBuildings: ['airfield'],
    tags: ['tier1', 'aircraft', 'technology']
  },

  petroleum_industry: {
    id: 'petroleum_industry',
    name: 'Petroleum Industry',
    description: 'Oil refining for fuel production.',
    tier: 'tier1',
    type: 'economic',
    cost: {
      manpower: 40,
      fuel: 30,
      ammo: 10,
      steel: 40,
      researchTime: 55
    },
    prerequisites: [],
    effects: [
      { type: 'fuel_production', value: 15, description: '+15 fuel/min' }
    ],
    unlocksBuildings: ['refinery'],
    tags: ['tier1', 'economic', 'resource']
  },

  // ========== TIER 2: INTERMEDIATE TECHNOLOGIES ==========
  medium_armor_doctrine: {
    id: 'medium_armor_doctrine',
    name: 'Medium Armor Doctrine',
    description: 'Develop versatile medium tanks for main battle line.',
    tier: 'tier2',
    type: 'doctrine',
    cost: {
      manpower: 80,
      fuel: 50,
      ammo: 35,
      steel: 70,
      researchTime: 90
    },
    prerequisites: [{ techId: 'light_armor_doctrine', tier: 'tier1' }],
    effects: [
      { type: 'damage_bonus', value: 0.12, targetType: 'medium_tank', stat: 'damage', description: '+12% medium tank damage' },
      { type: 'armor_bonus', value: 0.1, targetType: 'medium_tank', stat: 'armor', description: '+10% medium tank armor' }
    ],
    unlocksUnits: ['m4_sherman', 'panzer_iv', 't34_85'],
    tags: ['tier2', 'armor', 'doctrine']
  },

  anti_tank_weapons: {
    id: 'anti_tank_weapons',
    name: 'Anti-Tank Weapons',
    description: 'Develop portable anti-tank weapons for infantry.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 60,
      fuel: 20,
      ammo: 40,
      steel: 35,
      researchTime: 70
    },
    prerequisites: [{ techId: 'small_arms_upgrade', tier: 'tier1' }],
    effects: [
      { type: 'penetration_bonus', value: 0.2, targetType: 'anti_tank', stat: 'penetration', description: '+20% AT weapon penetration' }
    ],
    unlocksUnits: ['anti_tank_infantry'],
    tags: ['tier2', 'infantry', 'anti_tank']
  },

  mobile_artillery: {
    id: 'mobile_artillery',
    name: 'Mobile Artillery',
    description: 'Self-propelled artillery for mobile fire support.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 70,
      fuel: 45,
      ammo: 50,
      steel: 60,
      researchTime: 80
    },
    prerequisites: [{ techId: 'industrialization', tier: 'tier1' }],
    effects: [
      { type: 'mobility_bonus', value: 0.15, targetType: 'artillery', stat: 'speed', description: '+15% artillery mobility' }
    ],
    unlocksUnits: ['m7_priest'],
    tags: ['tier2', 'artillery', 'mobile']
  },

  rocket_artillery: {
    id: 'rocket_artillery',
    name: 'Rocket Artillery',
    description: 'Multiple rocket launchers for saturation bombardment.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 65,
      fuel: 40,
      ammo: 70,
      steel: 55,
      researchTime: 75
    },
    prerequisites: [{ techId: 'industrialization', tier: 'tier1' }],
    effects: [
      { type: 'splash_damage', value: 0.2, targetType: 'rocket_artillery', description: '+20% rocket splash damage' }
    ],
    unlocksUnits: ['nebelwerfer', 'katyusha'],
    tags: ['tier2', 'artillery', 'rocket']
  },

  advanced_fighters: {
    id: 'advanced_fighters',
    name: 'Advanced Fighters',
    description: 'Next-generation fighter aircraft with improved performance.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 70,
      fuel: 60,
      ammo: 45,
      steel: 65,
      researchTime: 85
    },
    prerequisites: [{ techId: 'aviation_technology', tier: 'tier1' }],
    effects: [
      { type: 'damage_bonus', value: 0.15, targetType: 'fighter', stat: 'damage', description: '+15% fighter damage' },
      { type: 'speed_bonus', value: 0.12, targetType: 'fighter', stat: 'speed', description: '+12% fighter speed' }
    ],
    unlocksUnits: ['p51_mustang'],
    tags: ['tier2', 'aircraft', 'fighter']
  },

  heavy_bombers: {
    id: 'heavy_bombers',
    name: 'Heavy Bombers',
    description: 'Strategic bombing capability with heavy bombers.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 90,
      fuel: 80,
      ammo: 70,
      steel: 85,
      researchTime: 95
    },
    prerequisites: [{ techId: 'aviation_technology', tier: 'tier1' }],
    effects: [
      { type: 'bomb_load', value: 0.25, targetType: 'bomber', description: '+25% bomber bomb load' }
    ],
    unlocksUnits: ['b17_flying_fortress'],
    tags: ['tier2', 'aircraft', 'bomber']
  },

  close_air_support: {
    id: 'close_air_support',
    name: 'Close Air Support',
    description: 'Dive bombers for precision ground attack.',
    tier: 'tier2',
    type: 'doctrine',
    cost: {
      manpower: 75,
      fuel: 65,
      ammo: 55,
      steel: 60,
      researchTime: 80
    },
    prerequisites: [{ techId: 'aviation_technology', tier: 'tier1' }],
    effects: [
      { type: 'accuracy_bonus', value: 0.2, targetType: 'cas', stat: 'accuracy', description: '+20% CAS accuracy' }
    ],
    unlocksUnits: ['stuka'],
    tags: ['tier2', 'aircraft', 'cas', 'doctrine']
  },

  radar_technology: {
    id: 'radar_technology',
    name: 'Radar Technology',
    description: 'Radio detection and ranging for early warning.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 60,
      fuel: 40,
      ammo: 30,
      steel: 55,
      researchTime: 70
    },
    prerequisites: [],
    effects: [
      { type: 'vision_bonus', value: 0.3, targetType: 'radar', description: '+30% radar detection range' }
    ],
    unlocksBuildings: ['radar_station'],
    tags: ['tier2', 'detection', 'technology']
  },

  aa_guns: {
    id: 'aa_guns',
    name: 'Anti-Air Guns',
    description: 'Dedicated anti-aircraft defense systems.',
    tier: 'tier2',
    type: 'military',
    cost: {
      manpower: 55,
      fuel: 35,
      ammo: 45,
      steel: 50,
      researchTime: 65
    },
    prerequisites: [{ techId: 'radar_technology', tier: 'tier2' }],
    effects: [
      { type: 'damage_bonus', value: 0.2, targetType: 'aa', stat: 'damage', description: '+20% AA damage' }
    ],
    unlocksBuildings: ['aa_emplacement'],
    tags: ['tier2', 'defense', 'anti_air']
  },

  mechanized_infantry: {
    id: 'mechanized_infantry',
    name: 'Mechanized Infantry',
    description: 'Motorized transport for rapid infantry deployment.',
    tier: 'tier2',
    type: 'doctrine',
    cost: {
      manpower: 65,
      fuel: 45,
      ammo: 30,
      steel: 50,
      researchTime: 70
    },
    prerequisites: [{ techId: 'industrialization', tier: 'tier1' }],
    effects: [
      { type: 'transport_capacity', value: 2, targetType: 'transport', description: '+2 transport capacity' }
    ],
    unlocksUnits: ['m3_halftrack'],
    tags: ['tier2', 'infantry', 'mechanized', 'doctrine']
  },

  logistics_corps: {
    id: 'logistics_corps',
    name: 'Logistics Corps',
    description: 'Organized supply system for sustained operations.',
    tier: 'tier2',
    type: 'economic',
    cost: {
      manpower: 50,
      fuel: 35,
      ammo: 25,
      steel: 40,
      researchTime: 60
    },
    prerequisites: [],
    effects: [
      { type: 'supply_efficiency', value: 0.2, description: '+20% supply efficiency' },
      { type: 'ammo_production', value: 12, description: '+12 ammo/min' }
    ],
    unlocksUnits: ['supply_truck'],
    tags: ['tier2', 'economic', 'logistics']
  },

  // ========== TIER 3: ADVANCED TECHNOLOGIES ==========
  heavy_armor_doctrine: {
    id: 'heavy_armor_doctrine',
    name: 'Heavy Armor Doctrine',
    description: 'Deploy heavy tanks as breakthrough forces.',
    tier: 'tier3',
    type: 'doctrine',
    cost: {
      manpower: 120,
      fuel: 80,
      ammo: 60,
      steel: 120,
      researchTime: 120
    },
    prerequisites: [{ techId: 'medium_armor_doctrine', tier: 'tier2' }],
    effects: [
      { type: 'damage_bonus', value: 0.18, targetType: 'heavy_tank', stat: 'damage', description: '+18% heavy tank damage' },
      { type: 'armor_bonus', value: 0.15, targetType: 'heavy_tank', stat: 'armor', description: '+15% heavy tank armor' }
    ],
    unlocksUnits: ['tiger_i', 'churchill', 'is2'],
    tags: ['tier3', 'armor', 'doctrine']
  },

  fortification_engineering: {
    id: 'fortification_engineering',
    name: 'Fortification Engineering',
    description: 'Advanced defensive structures and bunkers.',
    tier: 'tier3',
    type: 'military',
    cost: {
      manpower: 80,
      fuel: 40,
      ammo: 45,
      steel: 90,
      researchTime: 90
    },
    prerequisites: [{ techId: 'engineering_corps', tier: 'tier1' }],
    effects: [
      { type: 'armor_bonus', value: 0.25, targetType: 'bunker', stat: 'armor', description: '+25% bunker armor' }
    ],
    unlocksBuildings: ['bunker'],
    tags: ['tier3', 'defense', 'fortification']
  },

  coastal_defense: {
    id: 'coastal_defense',
    name: 'Coastal Defense',
    description: 'Long-range artillery emplacements.',
    tier: 'tier3',
    type: 'military',
    cost: {
      manpower: 85,
      fuel: 50,
      ammo: 70,
      steel: 85,
      researchTime: 95
    },
    prerequisites: [{ techId: 'mobile_artillery', tier: 'tier2' }],
    effects: [
      { type: 'range_bonus', value: 0.2, targetType: 'artillery', stat: 'range', description: '+20% artillery range' }
    ],
    unlocksBuildings: ['artillery_emplacement'],
    tags: ['tier3', 'defense', 'artillery']
  },

  scientific_method: {
    id: 'scientific_method',
    name: 'Scientific Method',
    description: 'Systematic research approach for faster development.',
    tier: 'tier3',
    type: 'economic',
    cost: {
      manpower: 70,
      fuel: 45,
      ammo: 35,
      steel: 65,
      researchTime: 85
    },
    prerequisites: [],
    effects: [
      { type: 'research_speed', value: 0.25, description: '+25% research speed' }
    ],
    unlocksBuildings: ['research_lab'],
    tags: ['tier3', 'economic', 'research']
  },

  heavy_industry: {
    id: 'heavy_industry',
    name: 'Heavy Industry',
    description: 'Large-scale steel production facilities.',
    tier: 'tier3',
    type: 'economic',
    cost: {
      manpower: 90,
      fuel: 60,
      ammo: 40,
      steel: 100,
      researchTime: 100
    },
    prerequisites: [{ techId: 'industrialization', tier: 'tier1' }],
    effects: [
      { type: 'steel_production', value: 25, description: '+25 steel/min' },
      { type: 'production_bonus', value: 0.15, targetType: 'heavy_vehicle', description: '+15% heavy vehicle production' }
    ],
    unlocksBuildings: ['steel_mill'],
    tags: ['tier3', 'economic', 'industry']
  },

  airborne_doctrine: {
    id: 'airborne_doctrine',
    name: 'Airborne Doctrine',
    description: 'Paratrooper operations behind enemy lines.',
    tier: 'tier3',
    type: 'doctrine',
    cost: {
      manpower: 85,
      fuel: 60,
      ammo: 50,
      steel: 55,
      researchTime: 90
    },
    prerequisites: [{ techId: 'aviation_technology', tier: 'tier1' }, { techId: 'officer_training', tier: 'tier1' }],
    effects: [
      { type: 'paradrop_range', value: 200, description: '+200 paradrop range' }
    ],
    unlocksUnits: ['paratrooper'],
    unlocksBuildings: ['airborne_command'],
    factionExclusive: ['allies'],
    tags: ['tier3', 'doctrine', 'airborne', 'allies']
  },

  precision_engineering: {
    id: 'precision_engineering',
    name: 'Precision Engineering',
    description: 'High-quality manufacturing for superior equipment.',
    tier: 'tier3',
    type: 'economic',
    cost: {
      manpower: 75,
      fuel: 50,
      ammo: 35,
      steel: 80,
      researchTime: 85
    },
    prerequisites: [{ techId: 'industrialization', tier: 'tier1' }],
    effects: [
      { type: 'hp_bonus', value: 0.1, targetType: 'vehicle', stat: 'hp', description: '+10% vehicle HP' }
    ],
    factionExclusive: ['axis'],
    tags: ['tier3', 'economic', 'engineering', 'axis']
  },

  guerrilla_tactics: {
    id: 'guerrilla_tactics',
    name: 'Guerrilla Tactics',
    description: 'Irregular warfare methods for resistance fighters.',
    tier: 'tier3',
    type: 'doctrine',
    cost: {
      manpower: 60,
      fuel: 30,
      ammo: 45,
      steel: 35,
      researchTime: 70
    },
    prerequisites: [{ techId: 'advanced_training', tier: 'tier1' }],
    effects: [
      { type: 'vision_bonus', value: 0.25, targetType: 'infantry', condition: 'terrain', description: '+25% vision in cover' },
      { type: 'cost_reduction', value: 0.15, targetType: 'infantry', description: '-15% infantry cost' }
    ],
    unlocksUnits: ['partisan', 'maquis', 'guerrilla_fighter'],
    unlocksBuildings: ['sabotage_camp'],
    factionExclusive: ['resistance'],
    tags: ['tier3', 'doctrine', 'guerrilla', 'resistance']
  },

  underground_network: {
    id: 'underground_network',
    name: 'Underground Network',
    description: 'Hidden facilities and supply routes.',
    tier: 'tier3',
    type: 'economic',
    cost: {
      manpower: 70,
      fuel: 40,
      ammo: 35,
      steel: 60,
      researchTime: 80
    },
    prerequisites: [{ techId: 'guerrilla_tactics', tier: 'tier3' }],
    effects: [
      { type: 'stealth', targetType: 'building', description: 'Buildings can be hidden' }
    ],
    unlocksBuildings: ['underground_bunker'],
    factionExclusive: ['resistance'],
    tags: ['tier3', 'economic', 'stealth', 'resistance']
  },

  // ========== TIER 4: ELITE TECHNOLOGIES ==========
  super_heavy_program: {
    id: 'super_heavy_program',
    name: 'Super Heavy Program',
    description: 'Development of massive super-heavy tanks.',
    tier: 'tier4',
    type: 'military',
    cost: {
      manpower: 180,
      fuel: 120,
      ammo: 100,
      steel: 200,
      researchTime: 150
    },
    prerequisites: [{ techId: 'heavy_armor_doctrine', tier: 'tier3' }, { techId: 'heavy_industry', tier: 'tier3' }],
    effects: [
      { type: 'unlock_super_heavy', description: 'Unlock super-heavy tank category' }
    ],
    tags: ['tier4', 'armor', 'super_heavy']
  },

  jet_technology: {
    id: 'jet_technology',
    name: 'Jet Technology',
    description: 'Revolutionary jet propulsion for aircraft.',
    tier: 'tier4',
    type: 'military',
    cost: {
      manpower: 150,
      fuel: 130,
      ammo: 90,
      steel: 160,
      researchTime: 140
    },
    prerequisites: [{ techId: 'advanced_fighters', tier: 'tier2' }],
    effects: [
      { type: 'speed_bonus', value: 0.5, targetType: 'jet', stat: 'speed', description: '+50% jet speed' }
    ],
    unlocksUnits: ['me262'],
    tags: ['tier4', 'aircraft', 'jet', 'advanced']
  },

  combined_arms: {
    id: 'combined_arms',
    name: 'Combined Arms Doctrine',
    description: 'Master coordination between all unit types.',
    tier: 'tier4',
    type: 'doctrine',
    cost: {
      manpower: 140,
      fuel: 90,
      ammo: 80,
      steel: 110,
      researchTime: 130
    },
    prerequisites: [
      { techId: 'officer_training', tier: 'tier1' },
      { techId: 'medium_armor_doctrine', tier: 'tier2' },
      { techId: 'close_air_support', tier: 'tier2' }
    ],
    effects: [
      { type: 'all_stats_bonus', value: 0.1, description: '+10% all stats when near different unit types' }
    ],
    factionExclusive: ['allies'],
    tags: ['tier4', 'doctrine', 'combined_arms', 'allies']
  },

  strategic_bombing: {
    id: 'strategic_bombing',
    name: 'Strategic Bombing Campaign',
    description: 'Massive bombing raids on enemy infrastructure.',
    tier: 'tier4',
    type: 'doctrine',
    cost: {
      manpower: 130,
      fuel: 140,
      ammo: 120,
      steel: 130,
      researchTime: 135
    },
    prerequisites: [{ techId: 'heavy_bombers', tier: 'tier2' }],
    effects: [
      { type: 'building_damage', value: 0.4, targetType: 'bomber', description: '+40% bomber damage vs buildings' }
    ],
    factionExclusive: ['allies'],
    tags: ['tier4', 'doctrine', 'bombing', 'allies']
  },

  blitzkrieg: {
    id: 'blitzkrieg',
    name: 'Blitzkrieg Doctrine',
    description: 'Lightning war tactics with fast armored thrusts.',
    tier: 'tier4',
    type: 'doctrine',
    cost: {
      manpower: 135,
      fuel: 110,
      ammo: 85,
      steel: 120,
      researchTime: 125
    },
    prerequisites: [
      { techId: 'light_armor_doctrine', tier: 'tier1' },
      { techId: 'medium_armor_doctrine', tier: 'tier2' }
    ],
    effects: [
      { type: 'speed_bonus', value: 0.2, targetType: 'tank', stat: 'speed', description: '+20% tank speed' },
      { type: 'encirclement_bonus', value: 0.3, description: '+30% bonus when encircling enemies' }
    ],
    factionExclusive: ['axis'],
    tags: ['tier4', 'doctrine', 'blitzkrieg', 'axis']
  },

  wunderwaffe: {
    id: 'wunderwaffe',
    name: 'Wunderwaffe Program',
    description: 'Wonder weapons and experimental technology.',
    tier: 'tier4',
    type: 'military',
    cost: {
      manpower: 160,
      fuel: 140,
      ammo: 110,
      steel: 180,
      researchTime: 145
    },
    prerequisites: [
      { techId: 'heavy_armor_doctrine', tier: 'tier3' },
      { techId: 'jet_technology', tier: 'tier4' }
    ],
    effects: [
      { type: 'experimental_access', description: 'Access to experimental tier' }
    ],
    factionExclusive: ['axis', 'experimental'],
    tags: ['tier4', 'experimental', 'wonder_weapon', 'axis']
  },

  people_war: {
    id: 'people_war',
    name: "People's War",
    description: 'Total mobilization of the population for war.',
    tier: 'tier4',
    type: 'economic',
    cost: {
      manpower: 120,
      fuel: 70,
      ammo: 90,
      steel: 90,
      researchTime: 115
    },
    prerequisites: [{ techId: 'guerrilla_tactics', tier: 'tier3' }],
    effects: [
      { type: 'manpower_production', value: 30, description: '+30 manpower/min' },
      { type: 'cost_reduction', value: 0.2, targetType: 'infantry', description: '-20% infantry cost' }
    ],
    factionExclusive: ['resistance'],
    tags: ['tier4', 'economic', 'mobilization', 'resistance']
  },

  // ========== EXPERIMENTAL TIER ==========
  nuclear_program: {
    id: 'nuclear_program',
    name: 'Nuclear Program',
    description: 'Development of atomic weapons.',
    tier: 'experimental',
    type: 'military',
    cost: {
      manpower: 200,
      fuel: 180,
      ammo: 150,
      steel: 250,
      researchTime: 200
    },
    prerequisites: [
      { techId: 'wunderwaffe', tier: 'tier4' },
      { techId: 'scientific_method', tier: 'tier3' }
    ],
    effects: [
      { type: 'nuke_unlock', description: 'Unlock atomic artillery' }
    ],
    unlocksUnits: ['atomic_artillery'],
    factionExclusive: ['experimental'],
    tags: ['experimental', 'nuclear', 'super_weapon']
  },

  prototype_program: {
    id: 'prototype_program',
    name: 'Prototype Development Program',
    description: 'Rapid prototyping of experimental weapons.',
    tier: 'experimental',
    type: 'economic',
    cost: {
      manpower: 170,
      fuel: 150,
      ammo: 120,
      steel: 200,
      researchTime: 170
    },
    prerequisites: [{ techId: 'scientific_method', tier: 'tier3' }],
    effects: [
      { type: 'build_time_reduction', value: 0.4, targetType: 'experimental', description: '-40% experimental build time' }
    ],
    unlocksBuildings: ['prototype_factory', 'advanced_research_lab'],
    factionExclusive: ['experimental'],
    tags: ['experimental', 'prototype', 'development']
  },

  advanced_science: {
    id: 'advanced_science',
    name: 'Advanced Science',
    description: 'Cutting-edge research methodologies.',
    tier: 'experimental',
    type: 'economic',
    cost: {
      manpower: 150,
      fuel: 120,
      ammo: 100,
      steel: 170,
      researchTime: 160
    },
    prerequisites: [{ techId: 'scientific_method', tier: 'tier3' }],
    effects: [
      { type: 'research_speed', value: 0.4, description: '+40% research speed' },
      { type: 'all_production_bonus', value: 0.2, description: '+20% all production' }
    ],
    factionExclusive: ['experimental'],
    tags: ['experimental', 'science', 'research']
  }
};

export function getTech(techId: string): Technology | undefined {
  return TECHNOLOGIES[techId];
}

export function getAllTechnologies(): Technology[] {
  return Object.values(TECHNOLOGIES);
}

export function getTechnologiesByTier(tier: TechTier): Technology[] {
  return Object.values(TECHNOLOGIES).filter(t => t.tier === tier);
}

export function getTechnologiesByFaction(factionId: string): Technology[] {
  return Object.values(TECHNOLOGIES).filter(t => 
    !t.factionExclusive || t.factionExclusive.includes(factionId)
  );
}

export function getAvailableTechnologies(unlockedTiers: TechTier[], factionId?: string): Technology[] {
  return Object.values(TECHNOLOGIES).filter(t => {
    if (!unlockedTiers.includes(t.tier)) return false;
    if (factionId && t.factionExclusive && !t.factionExclusive.includes(factionId)) return false;
    return true;
  });
}
