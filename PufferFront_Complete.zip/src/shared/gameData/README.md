# PufferFront - WW2 RTS Game Data

## Overview
PufferFront is a massive WWII-themed real-time strategy game built on the openfrontio framework. This document describes the comprehensive game data systems implemented.

## File Structure
```
src/shared/gameData/
├── index.ts           # Central export file
├── factions/
│   └── factions.ts    # Faction definitions (Allies, Axis, Resistance, Experimental)
├── units/
│   └── units.ts       # Unit definitions (Infantry, Tanks, Artillery, Aircraft)
├── buildings/
│   └── buildings.ts   # Building definitions (Production, Defense, Resource)
├── tech/
│   └── techTree.ts    # Technology tree (Tier 1-4 + Experimental)
└── maps/
    └── maps.ts        # Map definitions (Urban, Forest, Snow, Desert, Mixed)
```

## Factions

### Allied Forces
- **Color**: Blue (#4A90E2)
- **Bonuses**: Industrial Might (+15% vehicle/aircraft production), Air Superiority (+10% fighter damage)
- **Exclusive Units**: M4 Sherman, P-51 Mustang, B-17 Flying Fortress, M3 Halftrack, Paratrooper
- **Doctrines**: Combined Arms, Strategic Bombing, Amphibious Warfare

### Axis Powers
- **Color**: Red (#E24A4A)
- **Bonuses**: Blitzkrieg (+20% armored unit speed), Heavy Armor (+10% tank front armor)
- **Exclusive Units**: Tiger I, Panther, Me 262, Stuka, Panzergrenadier
- **Doctrines**: Blitzkrieg, Wunderwaffe, Fortress Europe

### Resistance Forces
- **Color**: Green (#5CB85C)
- **Bonuses**: Guerrilla Warfare (+25% vision in cover), Sabotage (-20% infantry cost)
- **Exclusive Units**: Partisan, Maquis, Home Guard, Guerrilla Fighter
- **Doctrines**: Guerrilla Tactics, Underground Network, People's War

### Experimental Division
- **Color**: Purple (#9B59B6)
- **Bonuses**: Advanced Research (+30% research speed), Prototype Power (+15% experimental damage)
- **Exclusive Units**: Landkreuzer, Ho 229, Atomic Artillery, Rocket Tank
- **Doctrines**: Wunderwaffe, Nuclear Program, Jet Age

## Units

### Infantry (7 types)
- **Rifleman**: Basic infantry, effective in cover
- **SMG Trooper**: Close-quarters specialist
- **Sniper**: Long-range elite marksman
- **Combat Engineer**: Builder and repair specialist
- **Field Medic**: Healing and revival
- **Infantry Officer**: Morale and coordination buffer
- **Anti-Tank Infantry**: Tank destroyer with high penetration

### Tanks (10+ types)
- **Light Tanks**: M3 Stuart (Allies), Panzer II (Axis)
- **Medium Tanks**: M4 Sherman, Panzer IV, T-34/85
- **Heavy Tanks**: Tiger I, Churchill Mk.VII, IS-2
- **Super Heavy**: Landkreuzer P.1500 (Experimental)

### Artillery (4 types)
- **Field Artillery**: M7 Priest (self-propelled howitzer)
- **Rocket Artillery**: Nebelwerfer 41 (Axis), Katyusha BM-13

### Aircraft (5+ types)
- **Fighters**: P-51 Mustang (Allies)
- **Jets**: Me 262 Schwalbe (Axis/Experimental)
- **Bombers**: B-17 Flying Fortress (Allies)
- **CAS**: Ju 87 Stuka (Axis)

### Support Units
- **Transport**: M3 Halftrack (APC)
- **Supply**: Supply Truck (logistics resupply)

## Buildings

### Command
- **Headquarters**: Main base, generates manpower

### Production
- **Barracks**: Trains infantry
- **Vehicle Factory**: Produces tanks and armored vehicles
- **Airfield**: Builds and houses aircraft

### Resource
- **Supply Depot**: Generates ammunition
- **Oil Refinery**: Generates fuel
- **Steel Mill**: Generates steel

### Defense
- **Radar Station**: Detection and early warning
- **AA Emplacement**: Anti-aircraft defense
- **Artillery Emplacement**: Long-range bombardment
- **Concrete Bunker**: Heavy fortification with garrison
- **Trench Line**: Light defensive earthworks

### Research
- **Research Laboratory**: Technology development

### Faction-Specific
- **Airborne Command Post** (Allies): Paratrooper operations
- **Heavy Tank Factory** (Axis): Super-heavy tank production
- **Underground Bunker** (Resistance): Hidden facility
- **Sabotage Camp** (Resistance): Guerrilla training
- **Advanced Research Lab** (Experimental): Cutting-edge tech
- **Prototype Factory** (Experimental): Experimental weapons

## Technology Tree

### Tier 1 (Basic)
- Small Arms Upgrade, Advanced Training, Engineering Corps
- Medical Corps, Officer Training, Light Armor Doctrine
- Industrialization, Aviation Technology, Petroleum Industry

### Tier 2 (Intermediate)
- Medium Armor Doctrine, Anti-Tank Weapons, Mobile Artillery
- Rocket Artillery, Advanced Fighters, Heavy Bombers
- Close Air Support, Radar Technology, AA Guns
- Mechanized Infantry, Logistics Corps

### Tier 3 (Advanced)
- Heavy Armor Doctrine, Fortification Engineering, Coastal Defense
- Scientific Method, Heavy Industry
- Airborne Doctrine (Allies), Precision Engineering (Axis)
- Guerrilla Tactics, Underground Network (Resistance)

### Tier 4 (Elite)
- Super Heavy Program, Jet Technology
- Combined Arms, Strategic Bombing (Allies)
- Blitzkrieg, Wunderwaffe (Axis)
- People's War (Resistance)

### Experimental
- Nuclear Program, Prototype Development Program, Advanced Science

## Maps

### Urban (2 maps)
- **Stalingrad Ruins**: Devastated city, close-quarters combat
- **Berlin Streets**: Final battle in German capital

### Forest (1 map)
- **Ardennes Forest**: Dense woodland, ambush tactics

### Plains (1 map)
- **Kursk Fields**: Open terrain, largest tank battle

### Snow (2 maps)
- **Moscow Outskirts**: Winter warfare
- **Leningrad Siege**: Frozen city under siege

### Desert (2 maps)
- **El Alamein**: North African tank battles
- **Tunisia Campaign**: Mountainous coastal terrain

### Mixed (3 maps)
- **Normandy Beachhead**: Allied invasion, amphibious assault
- **Market Garden**: Airborne operation, bridge capture

## Game Modes
- **Skirmish**: Standard deathmatch
- **Control Points**: Capture and hold objectives
- **Annihilation**: Eliminate all enemies
- **Conquest**: Total map domination

## Resources System
- **Manpower**: For infantry and basic operations
- **Fuel**: For vehicles and aircraft
- **Ammo**: For weapons and artillery
- **Steel**: For construction and heavy units

## Combat Mechanics
- **Armor System**: Front/Side/Rear/Top armor values
- **Penetration**: Weapon armor-piercing capability
- **Accuracy**: Hit chance with range falloff
- **Cover**: Terrain-based damage reduction
- **Morale**: Unit effectiveness under pressure
- **Supply Lines**: Logistics for sustained operations

## Contributors
- virusdragon
- voidborn
- pufferlander
- openfront

---
**PufferFront** - A WWII RTS Experience
