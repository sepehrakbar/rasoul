// PufferFront - Map Definitions
// WW2-themed maps with different terrains and strategic features

export type MapTerrain = 'urban' | 'forest' | 'snow' | 'desert' | 'plains' | 'mixed';
export type MapSize = 'small' | 'medium' | 'large' | 'huge';
export type GameMode = 'skirmish' | 'control_points' | 'annihilation' | 'conquest';

export interface MapResource {
  type: 'oil' | 'iron' | 'farmland' | 'city';
  position: { x: number; y: number };
  amount: number;
}

export interface MapObjective {
  id: string;
  type: 'capture_point' | 'victory_point' | 'strategic_location';
  position: { x: number; y: number };
  radius: number;
  captureTime: number; // seconds
  points?: number; // for control points mode
}

export interface TerrainFeature {
  type: 'river' | 'bridge' | 'hill' | 'forest' | 'urban' | 'road' | 'railroad';
  positions: Array<{ x: number; y: number }>;
  effects?: {
    movementPenalty?: number;
    coverBonus?: number;
    visionPenalty?: number;
  };
}

export interface GameMap {
  id: string;
  name: string;
  description: string;
  terrain: MapTerrain;
  size: MapSize;
  width: number;
  height: number;
  resources: MapResource[];
  objectives: MapObjective[];
  terrainFeatures: TerrainFeature[];
  spawnPoints: Array<{ x: number; y: number; team: number }>;
  recommendedPlayers: number;
  gameModes: GameMode[];
  tags: string[];
}

export const MAPS: Record<string, GameMap> = {
  // ========== URBAN MAPS ==========
  stalingrad_ruins: {
    id: 'stalingrad_ruins',
    name: 'Stalingrad Ruins',
    description: 'Devastated city streets with ruined buildings. Intense close-quarters combat.',
    terrain: 'urban',
    size: 'medium',
    width: 2000,
    height: 2000,
    resources: [
      { type: 'city', position: { x: 1000, y: 1000 }, amount: 100 },
      { type: 'iron', position: { x: 500, y: 500 }, amount: 60 },
      { type: 'oil', position: { x: 1500, y: 1500 }, amount: 50 }
    ],
    objectives: [
      {
        id: 'factory_district',
        type: 'victory_point',
        position: { x: 800, y: 900 },
        radius: 150,
        captureTime: 120,
        points: 50
      },
      {
        id: 'train_station',
        type: 'strategic_location',
        position: { x: 1200, y: 1100 },
        radius: 120,
        captureTime: 90,
        points: 30
      },
      {
        id: 'volga_crossing',
        type: 'capture_point',
        position: { x: 1000, y: 1800 },
        radius: 100,
        captureTime: 60,
        points: 20
      }
    ],
    terrainFeatures: [
      {
        type: 'urban',
        positions: [{ x: 1000, y: 1000 }],
        effects: { movementPenalty: 0.5, coverBonus: 0.6, visionPenalty: 0.4 }
      },
      {
        type: 'river',
        positions: [{ x: 1000, y: 1700 }, { x: 1100, y: 1750 }, { x: 900, y: 1750 }],
        effects: { movementPenalty: 0.9 }
      },
      {
        type: 'bridge',
        positions: [{ x: 1000, y: 1750 }],
        effects: {}
      }
    ],
    spawnPoints: [
      { x: 300, y: 300, team: 1 },
      { x: 1700, y: 1700, team: 2 }
    ],
    recommendedPlayers: 4,
    gameModes: ['control_points', 'annihilation', 'conquest'],
    tags: ['urban', 'ww2', 'iconic', 'close_quarters']
  },

  berlin_streets: {
    id: 'berlin_streets',
    name: 'Berlin Streets',
    description: 'Final battle in the German capital. Urban warfare at its finest.',
    terrain: 'urban',
    size: 'large',
    width: 2500,
    height: 2500,
    resources: [
      { type: 'city', position: { x: 1250, y: 1250 }, amount: 120 },
      { type: 'iron', position: { x: 600, y: 800 }, amount: 70 },
      { type: 'oil', position: { x: 1900, y: 1800 }, amount: 60 }
    ],
    objectives: [
      {
        id: 'reichstag',
        type: 'victory_point',
        position: { x: 1250, y: 1250 },
        radius: 200,
        captureTime: 180,
        points: 100
      },
      {
        id: 'tiergarten',
        type: 'capture_point',
        position: { x: 1000, y: 1400 },
        radius: 150,
        captureTime: 90,
        points: 30
      }
    ],
    terrainFeatures: [
      {
        type: 'urban',
        positions: [{ x: 1250, y: 1250 }],
        effects: { movementPenalty: 0.5, coverBonus: 0.6, visionPenalty: 0.4 }
      },
      {
        type: 'road',
        positions: [{ x: 800, y: 1250 }, { x: 1700, y: 1250 }],
        effects: { movementPenalty: -0.2 }
      }
    ],
    spawnPoints: [
      { x: 400, y: 400, team: 1 },
      { x: 2100, y: 2100, team: 2 }
    ],
    recommendedPlayers: 6,
    gameModes: ['control_points', 'annihilation', 'conquest'],
    tags: ['urban', 'ww2', 'historic', 'large']
  },

  // ========== FOREST MAPS ==========
  ardennes_forest: {
    id: 'ardennes_forest',
    name: 'Ardennes Forest',
    description: 'Dense woodland perfect for ambushes and armored thrusts.',
    terrain: 'forest',
    size: 'large',
    width: 3000,
    height: 2500,
    resources: [
      { type: 'farmland', position: { x: 1500, y: 1250 }, amount: 80 },
      { type: 'iron', position: { x: 800, y: 600 }, amount: 90 },
      { type: 'oil', position: { x: 2200, y: 1900 }, amount: 70 }
    ],
    objectives: [
      {
        id: 'crossroads_alpha',
        type: 'strategic_location',
        position: { x: 1200, y: 1000 },
        radius: 180,
        captureTime: 100,
        points: 40
      },
      {
        id: 'crossroads_beta',
        type: 'strategic_location',
        position: { x: 1800, y: 1500 },
        radius: 180,
        captureTime: 100,
        points: 40
      }
    ],
    terrainFeatures: [
      {
        type: 'forest',
        positions: [{ x: 1000, y: 800 }, { x: 1500, y: 1200 }, { x: 2000, y: 1600 }],
        effects: { movementPenalty: 0.3, coverBonus: 0.5, visionPenalty: 0.5 }
      },
      {
        type: 'river',
        positions: [{ x: 500, y: 1500 }, { x: 1000, y: 1800 }, { x: 1500, y: 2000 }],
        effects: { movementPenalty: 0.9 }
      },
      {
        type: 'road',
        positions: [{ x: 600, y: 800 }, { x: 2400, y: 1700 }],
        effects: { movementPenalty: -0.2 }
      }
    ],
    spawnPoints: [
      { x: 500, y: 500, team: 1 },
      { x: 2500, y: 2000, team: 2 }
    ],
    recommendedPlayers: 6,
    gameModes: ['skirmish', 'control_points', 'conquest'],
    tags: ['forest', 'ww2', 'ambush', 'armor_friendly']
  },

  kursk_fields: {
    id: 'kursk_fields',
    name: 'Kursk Fields',
    description: 'Open plains where the largest tank battle in history took place.',
    terrain: 'plains',
    size: 'huge',
    width: 4000,
    height: 3500,
    resources: [
      { type: 'farmland', position: { x: 2000, y: 1750 }, amount: 150 },
      { type: 'iron', position: { x: 1000, y: 1000 }, amount: 120 },
      { type: 'oil', position: { x: 3000, y: 2500 }, amount: 100 }
    ],
    objectives: [
      {
        id: 'hill_102',
        type: 'victory_point',
        position: { x: 2000, y: 1750 },
        radius: 250,
        captureTime: 150,
        points: 75
      },
      {
        id: 'railway_junction',
        type: 'strategic_location',
        position: { x: 1500, y: 2000 },
        radius: 200,
        captureTime: 120,
        points: 50
      }
    ],
    terrainFeatures: [
      {
        type: 'hill',
        positions: [{ x: 2000, y: 1750 }],
        effects: { visionPenalty: -0.3, coverBonus: 0.2 }
      },
      {
        type: 'railroad',
        positions: [{ x: 500, y: 1500 }, { x: 3500, y: 2000 }],
        effects: { movementPenalty: -0.1 }
      }
    ],
    spawnPoints: [
      { x: 600, y: 600, team: 1 },
      { x: 3400, y: 2900, team: 2 }
    ],
    recommendedPlayers: 8,
    gameModes: ['skirmish', 'annihilation', 'conquest'],
    tags: ['plains', 'ww2', 'tank_battle', 'open', 'huge']
  },

  // ========== SNOW MAPS ==========
  moscow_outskirts: {
    id: 'moscow_outskirts',
    name: 'Moscow Outskirts',
    description: 'Frozen wasteland outside the Soviet capital. Winter warfare.',
    terrain: 'snow',
    size: 'large',
    width: 3000,
    height: 2800,
    resources: [
      { type: 'city', position: { x: 1500, y: 1400 }, amount: 100 },
      { type: 'iron', position: { x: 700, y: 700 }, amount: 80 },
      { type: 'oil', position: { x: 2300, y: 2100 }, amount: 70 }
    ],
    objectives: [
      {
        id: 'supply_depot',
        type: 'strategic_location',
        position: { x: 1200, y: 1600 },
        radius: 160,
        captureTime: 100,
        points: 40
      },
      {
        id: 'airfield',
        type: 'victory_point',
        position: { x: 1800, y: 1200 },
        radius: 200,
        captureTime: 140,
        points: 60
      }
    ],
    terrainFeatures: [
      {
        type: 'forest',
        positions: [{ x: 800, y: 1000 }, { x: 2200, y: 1800 }],
        effects: { movementPenalty: 0.4, coverBonus: 0.5, visionPenalty: 0.4 }
      },
      {
        type: 'river',
        positions: [{ x: 1000, y: 800 }, { x: 1500, y: 1000 }, { x: 2000, y: 800 }],
        effects: { movementPenalty: 0.95 }
      }
    ],
    spawnPoints: [
      { x: 500, y: 500, team: 1 },
      { x: 2500, y: 2300, team: 2 }
    ],
    recommendedPlayers: 6,
    gameModes: ['skirmish', 'control_points', 'annihilation'],
    tags: ['snow', 'ww2', 'winter', 'historic']
  },

  leningrad_siege: {
    id: 'leningrad_siege',
    name: 'Leningrad Siege',
    description: 'Frozen city under siege. Survival against all odds.',
    terrain: 'snow',
    size: 'medium',
    width: 2200,
    height: 2200,
    resources: [
      { type: 'city', position: { x: 1100, y: 1100 }, amount: 90 },
      { type: 'farmland', position: { x: 600, y: 1600 }, amount: 50 }
    ],
    objectives: [
      {
        id: 'palace_square',
        type: 'victory_point',
        position: { x: 1100, y: 1100 },
        radius: 180,
        captureTime: 150,
        points: 80
      },
      {
        id: 'lake_ladoga',
        type: 'strategic_location',
        position: { x: 1800, y: 800 },
        radius: 140,
        captureTime: 90,
        points: 40
      }
    ],
    terrainFeatures: [
      {
        type: 'urban',
        positions: [{ x: 1100, y: 1100 }],
        effects: { movementPenalty: 0.5, coverBonus: 0.6, visionPenalty: 0.4 }
      },
      {
        type: 'river',
        positions: [{ x: 1600, y: 600 }, { x: 1900, y: 900 }],
        effects: { movementPenalty: 0.95 }
      }
    ],
    spawnPoints: [
      { x: 400, y: 400, team: 1 },
      { x: 1800, y: 1800, team: 2 }
    ],
    recommendedPlayers: 4,
    gameModes: ['control_points', 'annihilation'],
    tags: ['snow', 'ww2', 'siege', 'urban']
  },

  // ========== DESERT MAPS ==========
  el_alamein: {
    id: 'el_alamein',
    name: 'El Alamein',
    description: 'North African desert battlefield. Tank warfare in open terrain.',
    terrain: 'desert',
    size: 'large',
    width: 3500,
    height: 2800,
    resources: [
      { type: 'oil', position: { x: 1750, y: 1400 }, amount: 130 },
      { type: 'iron', position: { x: 900, y: 900 }, amount: 80 },
      { type: 'oil', position: { x: 2600, y: 2200 }, amount: 90 }
    ],
    objectives: [
      {
        id: 'coastal_road',
        type: 'strategic_location',
        position: { x: 1500, y: 1000 },
        radius: 200,
        captureTime: 110,
        points: 45
      },
      {
        id: 'qattara_depression',
        type: 'victory_point',
        position: { x: 2000, y: 1800 },
        radius: 220,
        captureTime: 140,
        points: 65
      }
    ],
    terrainFeatures: [
      {
        type: 'road',
        positions: [{ x: 500, y: 1000 }, { x: 3000, y: 1000 }],
        effects: { movementPenalty: -0.25 }
      },
      {
        type: 'hill',
        positions: [{ x: 1800, y: 1500 }],
        effects: { visionPenalty: -0.3, coverBonus: 0.15 }
      }
    ],
    spawnPoints: [
      { x: 600, y: 600, team: 1 },
      { x: 2900, y: 2200, team: 2 }
    ],
    recommendedPlayers: 6,
    gameModes: ['skirmish', 'control_points', 'annihilation'],
    tags: ['desert', 'ww2', 'africa', 'tank_battle']
  },

  tunisia_campaign: {
    id: 'tunisia_campaign',
    name: 'Tunisia Campaign',
    description: 'Mountainous North African terrain with coastal areas.',
    terrain: 'mixed',
    size: 'medium',
    width: 2600,
    height: 2400,
    resources: [
      { type: 'city', position: { x: 1300, y: 1200 }, amount: 85 },
      { type: 'oil', position: { x: 700, y: 1800 }, amount: 70 },
      { type: 'iron', position: { x: 1900, y: 700 }, amount: 65 }
    ],
    objectives: [
      {
        id: 'port_city',
        type: 'victory_point',
        position: { x: 1300, y: 1200 },
        radius: 180,
        captureTime: 130,
        points: 60
      },
      {
        id: 'mountain_pass',
        type: 'strategic_location',
        position: { x: 1800, y: 1600 },
        radius: 150,
        captureTime: 100,
        points: 40
      }
    ],
    terrainFeatures: [
      {
        type: 'hill',
        positions: [{ x: 1600, y: 1400 }, { x: 2000, y: 1800 }],
        effects: { visionPenalty: -0.25, coverBonus: 0.25 }
      },
      {
        type: 'road',
        positions: [{ x: 600, y: 1200 }, { x: 2000, y: 1200 }],
        effects: { movementPenalty: -0.2 }
      }
    ],
    spawnPoints: [
      { x: 500, y: 500, team: 1 },
      { x: 2100, y: 1900, team: 2 }
    ],
    recommendedPlayers: 4,
    gameModes: ['skirmish', 'control_points'],
    tags: ['mixed', 'ww2', 'africa', 'mountains']
  },

  // ========== MIXED TERRAIN MAPS ==========
  normandy_beachhead: {
    id: 'normandy_beachhead',
    name: 'Normandy Beachhead',
    description: 'Allied invasion beaches. Assault fortified positions.',
    terrain: 'mixed',
    size: 'large',
    width: 3200,
    height: 2600,
    resources: [
      { type: 'city', position: { x: 1600, y: 1300 }, amount: 95 },
      { type: 'farmland', position: { x: 1000, y: 1800 }, amount: 75 },
      { type: 'iron', position: { x: 2200, y: 900 }, amount: 70 }
    ],
    objectives: [
      {
        id: 'omaha_beach',
        type: 'victory_point',
        position: { x: 1400, y: 2200 },
        radius: 250,
        captureTime: 180,
        points: 100
      },
      {
        id: 'pointe_du_hoc',
        type: 'strategic_location',
        position: { x: 1000, y: 2000 },
        radius: 120,
        captureTime: 120,
        points: 50
      },
      {
        id: 'carentan',
        type: 'capture_point',
        position: { x: 1600, y: 1300 },
        radius: 180,
        captureTime: 100,
        points: 40
      }
    ],
    terrainFeatures: [
      {
        type: 'urban',
        positions: [{ x: 1600, y: 1300 }],
        effects: { movementPenalty: 0.5, coverBonus: 0.6, visionPenalty: 0.4 }
      },
      {
        type: 'hill',
        positions: [{ x: 1200, y: 1800 }],
        effects: { visionPenalty: -0.3, coverBonus: 0.3 }
      },
      {
        type: 'river',
        positions: [{ x: 1500, y: 1500 }, { x: 1700, y: 1700 }],
        effects: { movementPenalty: 0.8 }
      }
    ],
    spawnPoints: [
      { x: 1600, y: 2400, team: 1 },
      { x: 1600, y: 400, team: 2 }
    ],
    recommendedPlayers: 8,
    gameModes: ['control_points', 'conquest'],
    tags: ['mixed', 'ww2', 'invasion', 'historic', 'amphibious']
  },

  market_garden: {
    id: 'market_garden',
    name: 'Operation Market Garden',
    description: 'Airborne assault on Dutch bridges. Combined arms operation.',
    terrain: 'mixed',
    size: 'huge',
    width: 4000,
    height: 3000,
    resources: [
      { type: 'city', position: { x: 2000, y: 1500 }, amount: 110 },
      { type: 'farmland', position: { x: 1200, y: 2000 }, amount: 90 },
      { type: 'oil', position: { x: 2800, y: 1000 }, amount: 80 }
    ],
    objectives: [
      {
        id: 'arnhem_bridge',
        type: 'victory_point',
        position: { x: 2000, y: 800 },
        radius: 150,
        captureTime: 200,
        points: 150
      },
      {
        id: 'nijmegen_bridge',
        type: 'strategic_location',
        position: { x: 2000, y: 1500 },
        radius: 140,
        captureTime: 150,
        points: 80
      },
      {
        id: 'eindhoven_airfield',
        type: 'capture_point',
        position: { x: 2000, y: 2400 },
        radius: 180,
        captureTime: 100,
        points: 50
      }
    ],
    terrainFeatures: [
      {
        type: 'river',
        positions: [{ x: 1500, y: 1000 }, { x: 2500, y: 1000 }],
        effects: { movementPenalty: 0.9 }
      },
      {
        type: 'bridge',
        positions: [{ x: 2000, y: 800 }, { x: 2000, y: 1500 }],
        effects: {}
      },
      {
        type: 'urban',
        positions: [{ x: 2000, y: 1500 }],
        effects: { movementPenalty: 0.5, coverBonus: 0.6, visionPenalty: 0.4 }
      }
    ],
    spawnPoints: [
      { x: 2000, y: 2700, team: 1 },
      { x: 2000, y: 300, team: 2 }
    ],
    recommendedPlayers: 8,
    gameModes: ['control_points', 'conquest'],
    tags: ['mixed', 'ww2', 'airborne', 'bridges', 'historic']
  }
};

export function getMap(mapId: string): GameMap | undefined {
  return MAPS[mapId];
}

export function getAllMaps(): GameMap[] {
  return Object.values(MAPS);
}

export function getMapsByTerrain(terrain: MapTerrain): GameMap[] {
  return Object.values(MAPS).filter(m => m.terrain === terrain);
}

export function getMapsBySize(size: MapSize): GameMap[] {
  return Object.values(MAPS).filter(m => m.size === size);
}

export function getMapsByGameMode(mode: GameMode): GameMap[] {
  return Object.values(MAPS).filter(m => m.gameModes.includes(mode));
}

export function getRecommendedMaps(playerCount: number): GameMap[] {
  return Object.values(MAPS).filter(m => 
    Math.abs(m.recommendedPlayers - playerCount) <= 2
  );
}
