// PufferFront - Faction Definitions
// WW2-themed factions with unique units, doctrines, and playstyles

export interface FactionBonus {
  id: string;
  name: string;
  description: string;
  effect: {
    type: 'damage' | 'speed' | 'cost' | 'production' | 'vision' | 'armor';
    value: number;
    appliesTo?: string[]; // unit types or building types
  };
}

export interface Faction {
  id: string;
  name: string;
  description: string;
  color: string;
  bonuses: FactionBonus[];
  exclusiveUnits: string[];
  exclusiveBuildings: string[];
  doctrineTree: string[];
}

export const FACTIONS: Record<string, Faction> = {
  allies: {
    id: 'allies',
    name: 'Allied Forces',
    description: 'The Allied coalition focusing on industrial might, air superiority, and combined arms tactics.',
    color: '#4A90E2',
    bonuses: [
      {
        id: 'allies_industrial',
        name: 'Industrial Might',
        description: '+15% production speed for vehicles and aircraft',
        effect: { type: 'production', value: 0.15, appliesTo: ['vehicle', 'aircraft'] }
      },
      {
        id: 'allies_air',
        name: 'Air Superiority',
        description: '+10% damage for fighter aircraft',
        effect: { type: 'damage', value: 0.10, appliesTo: ['fighter', 'bomber'] }
      }
    ],
    exclusiveUnits: [
      'm4_sherman',
      'p51_mustang',
      'b17_flying_fortress',
      'm3_halftrack',
      'paratrooper'
    ],
    exclusiveBuildings: ['airborne_command'],
    doctrineTree: ['combined_arms', 'strategic_bombing', 'amphibious_warfare']
  },
  
  axis: {
    id: 'axis',
    name: 'Axis Powers',
    description: 'The Axis forces emphasizing blitzkrieg tactics, heavy armor, and technological innovation.',
    color: '#E24A4A',
    bonuses: [
      {
        id: 'axis_blitzkrieg',
        name: 'Blitzkrieg',
        description: '+20% movement speed for armored units',
        effect: { type: 'speed', value: 0.20, appliesTo: ['tank', 'armored_vehicle'] }
      },
      {
        id: 'axis_armor',
        name: 'Heavy Armor',
        description: '+10% front armor for all tanks',
        effect: { type: 'armor', value: 0.10, appliesTo: ['tank'] }
      }
    ],
    exclusiveUnits: [
      'tiger_i',
      'panther',
      'me262',
      'stuka',
      'panzergrenadier'
    ],
    exclusiveBuildings: ['heavy_tank_factory'],
    doctrineTree: ['blitzkrieg', 'wunderwaffe', 'fortress_europe']
  },
  
  resistance: {
    id: 'resistance',
    name: 'Resistance Forces',
    description: 'Guerrilla fighters specializing in ambush tactics, sabotage, and asymmetric warfare.',
    color: '#5CB85C',
    bonuses: [
      {
        id: 'resistance_guerrilla',
        name: 'Guerrilla Warfare',
        description: '+25% vision range in forests and urban terrain',
        effect: { type: 'vision', value: 0.25, appliesTo: ['infantry'] }
      },
      {
        id: 'resistance_sabotage',
        name: 'Sabotage',
        description: '-20% cost for infantry units',
        effect: { type: 'cost', value: -0.20, appliesTo: ['infantry'] }
      }
    ],
    exclusiveUnits: [
      'partisan',
      'maquis',
      'home_guard',
      'guerrilla_fighter'
    ],
    exclusiveBuildings: ['underground_bunker', 'sabotage_camp'],
    doctrineTree: ['guerrilla_tactics', 'underground_network', 'people_war']
  },
  
  experimental: {
    id: 'experimental',
    name: 'Experimental Division',
    description: 'Prototype weapons and advanced technology with high risk, high reward gameplay.',
    color: '#9B59B6',
    bonuses: [
      {
        id: 'experimental_tech',
        name: 'Advanced Research',
        description: '+30% research speed',
        effect: { type: 'production', value: 0.30, appliesTo: ['research'] }
      },
      {
        id: 'experimental_power',
        name: 'Prototype Power',
        description: '+15% damage for experimental units',
        effect: { type: 'damage', value: 0.15, appliesTo: ['experimental'] }
      }
    ],
    exclusiveUnits: [
      'landkreuzer',
      'ho229',
      'atomic_artillery',
      'rocket_tank'
    ],
    exclusiveBuildings: ['advanced_research_lab', 'prototype_factory'],
    doctrineTree: ['wunderwaffe', 'nuclear_program', 'jet_age']
  }
};

export function getFaction(factionId: string): Faction | undefined {
  return FACTIONS[factionId];
}

export function getAllFactions(): Faction[] {
  return Object.values(FACTIONS);
}
