// PufferFront - Unit Definitions
// Comprehensive WW2 units with armor, penetration, and detailed stats

export type UnitType = 'infantry' | 'tank' | 'armored_vehicle' | 'artillery' | 'aircraft' | 'support' | 'experimental';
export type UnitCategory = 'rifle' | 'smg' | 'sniper' | 'engineer' | 'medic' | 'officer' | 'anti_tank' | 
                           'light_tank' | 'medium_tank' | 'heavy_tank' | 'super_heavy_tank' |
                           'field_artillery' | 'rocket_artillery' | 'howitzer' | 'mortar' |
                           'fighter' | 'bomber' | 'recon' | 'cas' | 'jet' |
                           'transport' | 'supply';

export interface UnitStats {
  hp: number;
  armor: {
    front: number;
    side: number;
    rear: number;
    top: number;
  };
  penetration: number;
  damage: number;
  accuracy: number;
  range: number;
  speed: number;
  sightRange: number;
  reloadTime: number;
}

export interface UnitCost {
  manpower: number;
  fuel: number;
  ammo: number;
  steel: number;
  buildTime: number; // seconds
}

export interface UnitAbility {
  id: string;
  name: string;
  description: string;
  cooldown: number;
  duration?: number;
  effect: any;
}

export interface Unit {
  id: string;
  name: string;
  description: string;
  type: UnitType;
  category: UnitCategory;
  stats: UnitStats;
  cost: UnitCost;
  abilities: UnitAbility[];
  techRequirements: string[]; // tech IDs required to unlock
  factionExclusive?: string[]; // faction IDs that can use this unit
  tags: string[];
}

export const UNITS: Record<string, Unit> = {
  // ========== INFANTRY ==========
  rifleman: {
    id: 'rifleman',
    name: 'Rifleman',
    description: 'Standard infantry equipped with bolt-action rifles. Effective in cover and urban combat.',
    type: 'infantry',
    category: 'rifle',
    stats: {
      hp: 100,
      armor: { front: 2, side: 1, rear: 1, top: 0 },
      penetration: 5,
      damage: 15,
      accuracy: 0.75,
      range: 150,
      speed: 4,
      sightRange: 200,
      reloadTime: 1.5
    },
    cost: {
      manpower: 50,
      fuel: 0,
      ammo: 10,
      steel: 5,
      buildTime: 10
    },
    abilities: [
      {
        id: 'take_cover',
        name: 'Take Cover',
        description: 'Gain +50% armor when in cover',
        cooldown: 0,
        effect: { type: 'armor_bonus', value: 0.5, condition: 'in_cover' }
      }
    ],
    techRequirements: [],
    tags: ['infantry', 'basic', 'ww2']
  },

  smg_trooper: {
    id: 'smg_trooper',
    name: 'SMG Trooper',
    description: 'Close-quarters specialist with submachine gun. High rate of fire at short range.',
    type: 'infantry',
    category: 'smg',
    stats: {
      hp: 90,
      armor: { front: 2, side: 1, rear: 1, top: 0 },
      penetration: 4,
      damage: 12,
      accuracy: 0.65,
      range: 80,
      speed: 5,
      sightRange: 180,
      reloadTime: 0.8
    },
    cost: {
      manpower: 45,
      fuel: 0,
      ammo: 15,
      steel: 8,
      buildTime: 9
    },
    abilities: [
      {
        id: 'suppress',
        name: 'Suppressive Fire',
        description: 'Reduce enemy accuracy by 30%',
        cooldown: 8,
        duration: 4,
        effect: { type: 'debuff', stat: 'accuracy', value: -0.3 }
      }
    ],
    techRequirements: ['small_arms_upgrade'],
    tags: ['infantry', 'close_quarters', 'ww2']
  },

  sniper: {
    id: 'sniper',
    name: 'Sniper',
    description: 'Elite marksman with scoped rifle. Devastating at long range but vulnerable up close.',
    type: 'infantry',
    category: 'sniper',
    stats: {
      hp: 70,
      armor: { front: 1, side: 1, rear: 1, top: 0 },
      penetration: 25,
      damage: 80,
      accuracy: 0.95,
      range: 400,
      speed: 3,
      sightRange: 350,
      reloadTime: 3.0
    },
    cost: {
      manpower: 80,
      fuel: 0,
      ammo: 20,
      steel: 15,
      buildTime: 18
    },
    abilities: [
      {
        id: 'headshot',
        name: 'Headshot',
        description: 'Instant kill on infantry with 15% chance',
        cooldown: 0,
        effect: { type: 'crit', chance: 0.15, multiplier: 999 }
      },
      {
        id: 'camouflage',
        name: 'Camouflage',
        description: 'Remain hidden until firing',
        cooldown: 0,
        effect: { type: 'stealth', breakOnAttack: true }
      }
    ],
    techRequirements: ['advanced_training'],
    tags: ['infantry', 'long_range', 'elite', 'ww2']
  },

  engineer: {
    id: 'engineer',
    name: 'Combat Engineer',
    description: 'Specialist in constructing fortifications and clearing obstacles. Can repair buildings.',
    type: 'infantry',
    category: 'engineer',
    stats: {
      hp: 85,
      armor: { front: 3, side: 2, rear: 2, top: 0 },
      penetration: 8,
      damage: 18,
      accuracy: 0.70,
      range: 120,
      speed: 4,
      sightRange: 180,
      reloadTime: 1.8
    },
    cost: {
      manpower: 60,
      fuel: 0,
      ammo: 12,
      steel: 10,
      buildTime: 14
    },
    abilities: [
      {
        id: 'build_fortification',
        name: 'Build Fortification',
        description: 'Construct bunkers and trenches',
        cooldown: 0,
        effect: { type: 'construction', structures: ['bunker', 'trench', 'barbed_wire'] }
      },
      {
        id: 'repair',
        name: 'Repair',
        description: 'Repair buildings and vehicles',
        cooldown: 5,
        effect: { type: 'heal', target: 'building_vehicle', amount: 50 }
      }
    ],
    techRequirements: ['engineering_corps'],
    tags: ['infantry', 'support', 'builder', 'ww2']
  },

  medic: {
    id: 'medic',
    name: 'Field Medic',
    description: 'Medical specialist who heals nearby infantry units. Essential for sustained operations.',
    type: 'infantry',
    category: 'medic',
    stats: {
      hp: 75,
      armor: { front: 1, side: 1, rear: 1, top: 0 },
      penetration: 3,
      damage: 8,
      accuracy: 0.60,
      range: 100,
      speed: 5,
      sightRange: 160,
      reloadTime: 2.0
    },
    cost: {
      manpower: 55,
      fuel: 0,
      ammo: 8,
      steel: 5,
      buildTime: 12
    },
    abilities: [
      {
        id: 'heal_squad',
        name: 'Heal Squad',
        description: 'Heal all nearby infantry for 30 HP',
        cooldown: 10,
        duration: 0,
        effect: { type: 'aoe_heal', radius: 50, amount: 30, target: 'infantry' }
      },
      {
        id: 'revive',
        name: 'Revive',
        description: 'Revive one fallen infantry unit',
        cooldown: 30,
        effect: { type: 'revive', target: 'infantry', count: 1 }
      }
    ],
    techRequirements: ['medical_corps'],
    tags: ['infantry', 'support', 'healer', 'ww2']
  },

  officer: {
    id: 'officer',
    name: 'Infantry Officer',
    description: 'Command unit that boosts morale and coordination of nearby troops.',
    type: 'infantry',
    category: 'officer',
    stats: {
      hp: 90,
      armor: { front: 3, side: 2, rear: 2, top: 0 },
      penetration: 6,
      damage: 14,
      accuracy: 0.72,
      range: 130,
      speed: 4,
      sightRange: 220,
      reloadTime: 1.6
    },
    cost: {
      manpower: 70,
      fuel: 0,
      ammo: 10,
      steel: 8,
      buildTime: 15
    },
    abilities: [
      {
        id: 'morale_boost',
        name: 'Morale Boost',
        description: '+20% damage and +10% speed for nearby infantry',
        cooldown: 0,
        effect: { type: 'aura', radius: 80, buffs: [{ stat: 'damage', value: 0.2 }, { stat: 'speed', value: 0.1 }] }
      },
      {
        id: 'coordinate_attack',
        name: 'Coordinate Attack',
        description: 'All nearby units focus fire on target',
        cooldown: 20,
        effect: { type: 'focus_fire', radius: 100 }
      }
    ],
    techRequirements: ['officer_training'],
    tags: ['infantry', 'command', 'buffer', 'ww2']
  },

  anti_tank_infantry: {
    id: 'anti_tank_infantry',
    name: 'Anti-Tank Infantry',
    description: 'Equipped with Panzerfaust/Bazooka. Specialized in destroying armored vehicles.',
    type: 'infantry',
    category: 'anti_tank',
    stats: {
      hp: 80,
      armor: { front: 2, side: 1, rear: 1, top: 0 },
      penetration: 50,
      damage: 120,
      accuracy: 0.65,
      range: 100,
      speed: 4,
      sightRange: 180,
      reloadTime: 4.0
    },
    cost: {
      manpower: 65,
      fuel: 0,
      ammo: 25,
      steel: 12,
      buildTime: 16
    },
    abilities: [
      {
        id: 'armor_piercing',
        name: 'Armor Piercing',
        description: 'Ignore 30% of target armor',
        cooldown: 0,
        effect: { type: 'penetration_bonus', value: 0.3 }
      }
    ],
    techRequirements: ['anti_tank_weapons'],
    tags: ['infantry', 'anti_tank', 'ww2']
  },

  // ========== LIGHT TANKS ==========
  m3_stuart: {
    id: 'm3_stuart',
    name: 'M3 Stuart',
    description: 'American light tank. Fast and reliable with good reconnaissance capabilities.',
    type: 'tank',
    category: 'light_tank',
    stats: {
      hp: 320,
      armor: { front: 38, side: 22, rear: 13, top: 10 },
      penetration: 35,
      damage: 45,
      accuracy: 0.70,
      range: 300,
      speed: 12,
      sightRange: 350,
      reloadTime: 2.5
    },
    cost: {
      manpower: 80,
      fuel: 40,
      ammo: 30,
      steel: 60,
      buildTime: 35
    },
    abilities: [
      {
        id: 'recon',
        name: 'Reconnaissance',
        description: '+50% sight range',
        cooldown: 0,
        effect: { type: 'vision_bonus', value: 0.5 }
      }
    ],
    techRequirements: ['light_armor_doctrine'],
    factionExclusive: ['allies'],
    tags: ['tank', 'light', 'recon', 'allies', 'ww2']
  },

  panzer_ii: {
    id: 'panzer_ii',
    name: 'Panzer II',
    description: 'German light tank. Well-balanced for early war engagements.',
    type: 'tank',
    category: 'light_tank',
    stats: {
      hp: 300,
      armor: { front: 35, side: 20, rear: 15, top: 10 },
      penetration: 32,
      damage: 40,
      accuracy: 0.72,
      range: 280,
      speed: 11,
      sightRange: 320,
      reloadTime: 2.3
    },
    cost: {
      manpower: 75,
      fuel: 38,
      ammo: 28,
      steel: 55,
      buildTime: 32
    },
    abilities: [],
    techRequirements: ['light_armor_doctrine'],
    factionExclusive: ['axis'],
    tags: ['tank', 'light', 'axis', 'ww2']
  },

  // ========== MEDIUM TANKS ==========
  m4_sherman: {
    id: 'm4_sherman',
    name: 'M4 Sherman',
    description: 'Iconic American medium tank. Reliable, numerous, and effective in combined arms.',
    type: 'tank',
    category: 'medium_tank',
    stats: {
      hp: 520,
      armor: { front: 63, side: 38, rear: 30, top: 15 },
      penetration: 55,
      damage: 70,
      accuracy: 0.68,
      range: 350,
      speed: 9,
      sightRange: 300,
      reloadTime: 3.0
    },
    cost: {
      manpower: 120,
      fuel: 60,
      ammo: 45,
      steel: 100,
      buildTime: 50
    },
    abilities: [
      {
        id: 'stabilized_gun',
        name: 'Stabilized Gun',
        description: 'Can fire accurately while moving',
        cooldown: 0,
        effect: { type: 'fire_on_move', accuracyPenalty: 0.1 }
      }
    ],
    techRequirements: ['medium_armor_doctrine'],
    factionExclusive: ['allies'],
    tags: ['tank', 'medium', 'allies', 'ww2', 'iconic']
  },

  panzer_iv: {
    id: 'panzer_iv',
    name: 'Panzer IV',
    description: 'German workhorse medium tank. Versatile and upgraded throughout the war.',
    type: 'tank',
    category: 'medium_tank',
    stats: {
      hp: 500,
      armor: { front: 60, side: 35, rear: 28, top: 15 },
      penetration: 58,
      damage: 72,
      accuracy: 0.70,
      range: 360,
      speed: 8,
      sightRange: 290,
      reloadTime: 2.8
    },
    cost: {
      manpower: 115,
      fuel: 58,
      ammo: 43,
      steel: 95,
      buildTime: 48
    },
    abilities: [],
    techRequirements: ['medium_armor_doctrine'],
    factionExclusive: ['axis'],
    tags: ['tank', 'medium', 'axis', 'ww2']
  },

  t34_85: {
    id: 't34_85',
    name: 'T-34/85',
    description: 'Soviet medium tank. Sloped armor and powerful gun make it a formidable opponent.',
    type: 'tank',
    category: 'medium_tank',
    stats: {
      hp: 540,
      armor: { front: 70, side: 40, rear: 30, top: 18 },
      penetration: 60,
      damage: 75,
      accuracy: 0.65,
      range: 340,
      speed: 10,
      sightRange: 280,
      reloadTime: 3.2
    },
    cost: {
      manpower: 110,
      fuel: 55,
      ammo: 40,
      steel: 90,
      buildTime: 45
    },
    abilities: [
      {
        id: 'sloped_armor',
        name: 'Sloped Armor',
        description: '+20% effective armor against frontal attacks',
        cooldown: 0,
        effect: { type: 'armor_bonus', value: 0.2, condition: 'frontal_hit' }
      }
    ],
    techRequirements: ['medium_armor_doctrine'],
    tags: ['tank', 'medium', 'ww2']
  },

  // ========== HEAVY TANKS ==========
  tiger_i: {
    id: 'tiger_i',
    name: 'Tiger I',
    description: 'German heavy tank. Thick armor and devastating 88mm gun inspire fear on the battlefield.',
    type: 'tank',
    category: 'heavy_tank',
    stats: {
      hp: 850,
      armor: { front: 100, side: 60, rear: 40, top: 25 },
      penetration: 90,
      damage: 130,
      accuracy: 0.75,
      range: 450,
      speed: 6,
      sightRange: 320,
      reloadTime: 4.5
    },
    cost: {
      manpower: 200,
      fuel: 100,
      ammo: 70,
      steel: 180,
      buildTime: 80
    },
    abilities: [
      {
        id: 'fear',
        name: 'Intimidating Presence',
        description: 'Reduce enemy morale within range',
        cooldown: 0,
        effect: { type: 'aura_debuff', radius: 150, stat: 'accuracy', value: -0.15 }
      }
    ],
    techRequirements: ['heavy_armor_doctrine'],
    factionExclusive: ['axis'],
    tags: ['tank', 'heavy', 'axis', 'ww2', 'iconic']
  },

  churchill: {
    id: 'churchill',
    name: 'Churchill Mk.VII',
    description: 'British heavy infantry tank. Extremely thick armor for breakthrough operations.',
    type: 'tank',
    category: 'heavy_tank',
    stats: {
      hp: 900,
      armor: { front: 152, side: 95, rear: 50, top: 20 },
      penetration: 65,
      damage: 85,
      accuracy: 0.62,
      range: 380,
      speed: 5,
      sightRange: 280,
      reloadTime: 4.0
    },
    cost: {
      manpower: 190,
      fuel: 95,
      ammo: 65,
      steel: 170,
      buildTime: 75
    },
    abilities: [
      {
        id: 'fortress',
        name: 'Mobile Fortress',
        description: '+50% armor when stationary',
        cooldown: 0,
        effect: { type: 'armor_bonus', value: 0.5, condition: 'stationary' }
      }
    ],
    techRequirements: ['heavy_armor_doctrine'],
    factionExclusive: ['allies'],
    tags: ['tank', 'heavy', 'allies', 'ww2']
  },

  is2: {
    id: 'is2',
    name: 'IS-2',
    description: 'Soviet heavy tank. Massive 122mm gun capable of destroying any German tank.',
    type: 'tank',
    category: 'heavy_tank',
    stats: {
      hp: 880,
      armor: { front: 120, side: 70, rear: 45, top: 30 },
      penetration: 110,
      damage: 160,
      accuracy: 0.60,
      range: 420,
      speed: 6,
      sightRange: 300,
      reloadTime: 5.5
    },
    cost: {
      manpower: 210,
      fuel: 105,
      ammo: 75,
      steel: 190,
      buildTime: 85
    },
    abilities: [
      {
        id: 'shell_shock',
        name: 'Shell Shock',
        description: 'HE shell stuns nearby enemies',
        cooldown: 0,
        effect: { type: 'splash_stun', radius: 30, duration: 2 }
      }
    ],
    techRequirements: ['heavy_armor_doctrine'],
    tags: ['tank', 'heavy', 'ww2']
  },

  // ========== SUPER HEAVY TANKS ==========
  landkreuzer: {
    id: 'landkreuzer',
    name: 'Landkreuzer P.1500',
    description: 'German super-heavy tank prototype. A mobile fortress with multiple guns.',
    type: 'tank',
    category: 'super_heavy_tank',
    stats: {
      hp: 2500,
      armor: { front: 220, side: 150, rear: 100, top: 50 },
      penetration: 150,
      damage: 300,
      accuracy: 0.55,
      range: 600,
      speed: 3,
      sightRange: 400,
      reloadTime: 8.0
    },
    cost: {
      manpower: 500,
      fuel: 300,
      ammo: 200,
      steel: 500,
      buildTime: 200
    },
    abilities: [
      {
        id: 'multiple_guns',
        name: 'Multiple Turrets',
        description: 'Can engage multiple targets simultaneously',
        cooldown: 0,
        effect: { type: 'multi_target', count: 3 }
      },
      {
        id: 'unstoppable',
        name: 'Unstoppable',
        description: 'Immune to suppression effects',
        cooldown: 0,
        effect: { type: 'immunity', status: ['suppressed', 'stunned'] }
      }
    ],
    techRequirements: ['super_heavy_program', 'wunderwaffe'],
    factionExclusive: ['experimental', 'axis'],
    tags: ['tank', 'super_heavy', 'experimental', 'prototype', 'ww2']
  },

  // ========== ARTILLERY ==========
  m7_priest: {
    id: 'm7_priest',
    name: 'M7 Priest',
    description: 'American self-propelled howitzer. Mobile artillery support for advancing troops.',
    type: 'artillery',
    category: 'field_artillery',
    stats: {
      hp: 280,
      armor: { front: 25, side: 15, rear: 10, top: 8 },
      penetration: 20,
      damage: 90,
      accuracy: 0.50,
      range: 550,
      speed: 8,
      sightRange: 250,
      reloadTime: 6.0
    },
    cost: {
      manpower: 90,
      fuel: 50,
      ammo: 60,
      steel: 70,
      buildTime: 40
    },
    abilities: [
      {
        id: 'indirect_fire',
        name: 'Indirect Fire',
        description: 'Fire without line of sight using forward observers',
        cooldown: 0,
        effect: { type: 'indirect_fire', requiresObserver: true }
      },
      {
        id: 'barrage',
        name: 'Artillery Barrage',
        description: 'Saturation fire over large area',
        cooldown: 25,
        effect: { type: 'aoe_damage', radius: 80, damageMultiplier: 1.5 }
      }
    ],
    techRequirements: ['mobile_artillery'],
    factionExclusive: ['allies'],
    tags: ['artillery', 'self_propelled', 'allies', 'ww2']
  },

  nebelwerfer: {
    id: 'nebelwerfer',
    name: 'Nebelwerfer 41',
    description: 'German rocket artillery. Devastating saturation fire but long reload time.',
    type: 'artillery',
    category: 'rocket_artillery',
    stats: {
      hp: 180,
      armor: { front: 15, side: 10, rear: 8, top: 5 },
      penetration: 15,
      damage: 120,
      accuracy: 0.40,
      range: 600,
      speed: 7,
      sightRange: 220,
      reloadTime: 12.0
    },
    cost: {
      manpower: 70,
      fuel: 35,
      ammo: 80,
      steel: 50,
      buildTime: 35
    },
    abilities: [
      {
        id: 'rocket_salvo',
        name: 'Rocket Salvo',
        description: 'Fire all rockets in rapid succession',
        cooldown: 0,
        effect: { type: 'salvo', shots: 6, interval: 0.5 }
      }
    ],
    techRequirements: ['rocket_artillery'],
    factionExclusive: ['axis'],
    tags: ['artillery', 'rocket', 'axis', 'ww2']
  },

  katyusha: {
    id: 'katyusha',
    name: 'Katyusha BM-13',
    description: 'Soviet truck-mounted rocket launcher. Famous for its terrifying barrage.',
    type: 'artillery',
    category: 'rocket_artillery',
    stats: {
      hp: 160,
      armor: { front: 10, side: 8, rear: 6, top: 4 },
      penetration: 12,
      damage: 100,
      accuracy: 0.35,
      range: 580,
      speed: 9,
      sightRange: 200,
      reloadTime: 10.0
    },
    cost: {
      manpower: 60,
      fuel: 30,
      ammo: 70,
      steel: 45,
      buildTime: 30
    },
    abilities: [
      {
        id: ' Stalin_organ',
        name: "Stalin's Organ",
        description: 'Psychological impact reduces enemy morale',
        cooldown: 0,
        effect: { type: 'morale_damage', radius: 100, value: 0.3 }
      }
    ],
    techRequirements: ['rocket_artillery'],
    tags: ['artillery', 'rocket', 'ww2']
  },

  // ========== AIRCRAFT ==========
  p51_mustang: {
    id: 'p51_mustang',
    name: 'P-51 Mustang',
    description: 'American long-range fighter. Excellent dogfighter and bomber escort.',
    type: 'aircraft',
    category: 'fighter',
    stats: {
      hp: 200,
      armor: { front: 15, side: 10, rear: 8, top: 5 },
      penetration: 25,
      damage: 35,
      accuracy: 0.75,
      range: 800,
      speed: 18,
      sightRange: 500,
      reloadTime: 1.2
    },
    cost: {
      manpower: 40,
      fuel: 80,
      ammo: 50,
      steel: 60,
      buildTime: 45
    },
    abilities: [
      {
        id: 'long_range_escort',
        name: 'Long Range Escort',
        description: 'Extended operational range',
        cooldown: 0,
        effect: { type: 'range_bonus', value: 0.4 }
      },
      {
        id: 'dogfight_expert',
        name: 'Dogfight Expert',
        description: '+25% damage against other fighters',
        cooldown: 0,
        effect: { type: 'damage_bonus', vs: 'fighter', value: 0.25 }
      }
    ],
    techRequirements: ['advanced_fighters'],
    factionExclusive: ['allies'],
    tags: ['aircraft', 'fighter', 'allies', 'ww2', 'iconic']
  },

  me262: {
    id: 'me262',
    name: 'Me 262 Schwalbe',
    description: 'German jet fighter. First operational jet aircraft with superior speed.',
    type: 'aircraft',
    category: 'jet',
    stats: {
      hp: 220,
      armor: { front: 18, side: 12, rear: 10, top: 6 },
      penetration: 30,
      damage: 45,
      accuracy: 0.70,
      range: 600,
      speed: 28,
      sightRange: 480,
      reloadTime: 1.0
    },
    cost: {
      manpower: 50,
      fuel: 120,
      ammo: 70,
      steel: 90,
      buildTime: 60
    },
    abilities: [
      {
        id: 'jet_speed',
        name: 'Jet Propulsion',
        description: 'Cannot be intercepted by propeller aircraft',
        cooldown: 0,
        effect: { type: 'intercept_immunity', vs: 'propeller' }
      },
      {
        id: 'rocket_armament',
        name: 'R4M Rockets',
        description: 'Devastating attack against bombers',
        cooldown: 15,
        effect: { type: 'burst_damage', damage: 150, vs: 'bomber' }
      }
    ],
    techRequirements: ['jet_technology', 'wunderwaffe'],
    factionExclusive: ['axis', 'experimental'],
    tags: ['aircraft', 'jet', 'axis', 'experimental', 'ww2', 'advanced']
  },

  b17_flying_fortress: {
    id: 'b17_flying_fortress',
    name: 'B-17 Flying Fortress',
    description: 'American heavy bomber. Heavily armed for strategic bombing campaigns.',
    type: 'aircraft',
    category: 'bomber',
    stats: {
      hp: 450,
      armor: { front: 25, side: 18, rear: 15, top: 10 },
      penetration: 20,
      damage: 80,
      accuracy: 0.45,
      range: 1000,
      speed: 10,
      sightRange: 400,
      reloadTime: 4.0
    },
    cost: {
      manpower: 100,
      fuel: 150,
      ammo: 120,
      steel: 140,
      buildTime: 90
    },
    abilities: [
      {
        id: 'defensive_guns',
        name: 'Defensive Gun Turrets',
        description: 'Can defend against fighter attacks',
        cooldown: 0,
        effect: { type: 'self_defense', damageReduction: 0.3 }
      },
      {
        id: 'strategic_bombing',
        name: 'Strategic Bombing',
        description: 'Bonus damage to buildings and infrastructure',
        cooldown: 0,
        effect: { type: 'damage_bonus', vs: 'building', value: 0.5 }
      }
    ],
    techRequirements: ['heavy_bombers'],
    factionExclusive: ['allies'],
    tags: ['aircraft', 'bomber', 'allies', 'ww2', 'iconic']
  },

  stuka: {
    id: 'stuka',
    name: 'Ju 87 Stuka',
    description: 'German dive bomber. Precision ground attack with terrifying siren.',
    type: 'aircraft',
    category: 'cas',
    stats: {
      hp: 280,
      armor: { front: 20, side: 15, rear: 12, top: 8 },
      penetration: 40,
      damage: 110,
      accuracy: 0.80,
      range: 500,
      speed: 12,
      sightRange: 350,
      reloadTime: 5.0
    },
    cost: {
      manpower: 70,
      fuel: 90,
      ammo: 80,
      steel: 75,
      buildTime: 55
    },
    abilities: [
      {
        id: 'dive_bomb',
        name: 'Precision Dive Bomb',
        description: 'High accuracy attack on ground targets',
        cooldown: 0,
        effect: { type: 'precision_strike', accuracyBonus: 0.3 }
      },
      {
        id: 'jericho_trumpet',
        name: 'Jericho Trumpet',
        description: 'Siren reduces enemy morale',
        cooldown: 20,
        effect: { type: 'morale_damage', radius: 150, value: 0.4 }
      }
    ],
    techRequirements: ['close_air_support'],
    factionExclusive: ['axis'],
    tags: ['aircraft', 'cas', 'dive_bomber', 'axis', 'ww2', 'iconic']
  },

  // ========== SUPPORT UNITS ==========
  m3_halftrack: {
    id: 'm3_halftrack',
    name: 'M3 Halftrack',
    description: 'American armored personnel carrier. Transports infantry safely across battlefield.',
    type: 'armored_vehicle',
    category: 'transport',
    stats: {
      hp: 240,
      armor: { front: 20, side: 12, rear: 10, top: 6 },
      penetration: 15,
      damage: 25,
      accuracy: 0.60,
      range: 200,
      speed: 11,
      sightRange: 280,
      reloadTime: 2.0
    },
    cost: {
      manpower: 60,
      fuel: 35,
      ammo: 20,
      steel: 45,
      buildTime: 30
    },
    abilities: [
      {
        id: 'transport',
        name: 'Infantry Transport',
        description: 'Carry up to 8 infantry units',
        cooldown: 0,
        effect: { type: 'transport', capacity: 8, targetType: 'infantry' }
      }
    ],
    techRequirements: ['mechanized_infantry'],
    factionExclusive: ['allies'],
    tags: ['vehicle', 'transport', 'allies', 'ww2']
  },

  supply_truck: {
    id: 'supply_truck',
    name: 'Supply Truck',
    description: 'Logistics vehicle that resupplies ammunition and fuel to frontline units.',
    type: 'support',
    category: 'supply',
    stats: {
      hp: 120,
      armor: { front: 8, side: 5, rear: 4, top: 2 },
      penetration: 0,
      damage: 0,
      accuracy: 0,
      range: 0,
      speed: 10,
      sightRange: 200,
      reloadTime: 0
    },
    cost: {
      manpower: 30,
      fuel: 25,
      ammo: 0,
      steel: 20,
      buildTime: 20
    },
    abilities: [
      {
        id: 'resupply',
        name: 'Resupply',
        description: 'Restore ammo and fuel to nearby units',
        cooldown: 15,
        effect: { type: 'resupply', radius: 60, ammoAmount: 50, fuelAmount: 30 }
      }
    ],
    techRequirements: ['logistics_corps'],
    tags: ['support', 'logistics', 'ww2']
  }
};

export function getUnit(unitId: string): Unit | undefined {
  return UNITS[unitId];
}

export function getAllUnits(): Unit[] {
  return Object.values(UNITS);
}

export function getUnitsByType(type: UnitType): Unit[] {
  return Object.values(UNITS).filter(u => u.type === type);
}

export function getUnitsByFaction(factionId: string): Unit[] {
  return Object.values(UNITS).filter(u => 
    !u.factionExclusive || u.factionExclusive.includes(factionId)
  );
}
