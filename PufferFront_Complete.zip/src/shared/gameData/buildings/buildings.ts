// PufferFront - Building Definitions
// WW2-themed buildings for base construction and unit production

export type BuildingType = 'hq' | 'production' | 'military' | 'defense' | 'support' | 'research';
export type BuildingCategory = 
  'command' | 
  'barracks' | 'vehicle_factory' | 'airfield' | 
  'supply_depot' | 'refinery' | 
  'radar' | 'aa_emplacement' | 'artillery_emplacement' | 
  'bunker' | 'trench' | 
  'research_lab';

export interface BuildingStats {
  hp: number;
  armor: number;
  sightRange: number;
  buildTime: number; // seconds
  garrisonCapacity?: number; // for defensive buildings
}

export interface BuildingCost {
  manpower: number;
  fuel: number;
  ammo: number;
  steel: number;
}

export interface BuildingProduction {
  resourceType?: 'manpower' | 'fuel' | 'ammo' | 'steel';
  productionRate: number; // per minute
}

export interface BuildingAbility {
  id: string;
  name: string;
  description: string;
  cooldown?: number;
  effect: any;
}

export interface Building {
  id: string;
  name: string;
  description: string;
  type: BuildingType;
  category: BuildingCategory;
  stats: BuildingStats;
  cost: BuildingCost;
  production?: BuildingProduction;
  abilities: BuildingAbility[];
  techRequirements: string[];
  factionExclusive?: string[];
  producesUnits?: string[]; // unit IDs that can be produced here
  tags: string[];
}

export const BUILDINGS: Record<string, Building> = {
  // ========== COMMAND BUILDINGS ==========
  hq: {
    id: 'hq',
    name: 'Headquarters',
    description: 'Main command center. Capturing enemy HQs provides strategic advantages.',
    type: 'hq',
    category: 'command',
    stats: {
      hp: 2000,
      armor: 50,
      sightRange: 400,
      buildTime: 120
    },
    cost: {
      manpower: 200,
      fuel: 100,
      ammo: 50,
      steel: 200
    },
    production: {
      resourceType: 'manpower',
      productionRate: 30
    },
    abilities: [
      {
        id: 'command_aura',
        name: 'Command Aura',
        description: '+10% production speed for all buildings within range',
        cooldown: 0,
        effect: { type: 'aura', radius: 300, buff: { type: 'production_speed', value: 0.1 } }
      },
      {
        id: 'reinforcements',
        name: 'Call Reinforcements',
        description: 'Spawn emergency infantry squad',
        cooldown: 180,
        effect: { type: 'spawn', units: ['rifleman'], count: 5 }
      }
    ],
    techRequirements: [],
    producesUnits: [],
    tags: ['hq', 'command', 'essential']
  },

  // ========== PRODUCTION BUILDINGS ==========
  barracks: {
    id: 'barracks',
    name: 'Barracks',
    description: 'Training facility for infantry units. Can be upgraded for advanced troops.',
    type: 'production',
    category: 'barracks',
    stats: {
      hp: 800,
      armor: 20,
      sightRange: 200,
      buildTime: 45
    },
    cost: {
      manpower: 100,
      fuel: 30,
      ammo: 20,
      steel: 60
    },
    abilities: [
      {
        id: 'rapid_training',
        name: 'Rapid Training',
        description: 'Reduce infantry training time by 25%',
        cooldown: 60,
        duration: 30,
        effect: { type: 'production_speed', value: 0.25, targetType: 'infantry' }
      }
    ],
    techRequirements: [],
    producesUnits: ['rifleman', 'smg_trooper', 'sniper', 'engineer', 'medic', 'officer', 'anti_tank_infantry'],
    tags: ['production', 'infantry', 'basic']
  },

  vehicle_factory: {
    id: 'vehicle_factory',
    name: 'Vehicle Factory',
    description: 'Manufactures tanks and armored vehicles. Requires steel and fuel.',
    type: 'production',
    category: 'vehicle_factory',
    stats: {
      hp: 1200,
      armor: 35,
      sightRange: 250,
      buildTime: 70
    },
    cost: {
      manpower: 150,
      fuel: 80,
      ammo: 40,
      steel: 150
    },
    abilities: [
      {
        id: 'assembly_line',
        name: 'Assembly Line',
        description: 'Produce two light vehicles simultaneously',
        cooldown: 120,
        effect: { type: 'dual_production', maxCost: 50 }
      }
    ],
    techRequirements: ['industrialization'],
    producesUnits: ['m3_stuart', 'panzer_ii', 'm4_sherman', 'panzer_iv', 't34_85', 'tiger_i', 'churchill', 'is2', 'landkreuzer', 'm3_halftrack', 'supply_truck'],
    tags: ['production', 'vehicles', 'armor']
  },

  airfield: {
    id: 'airfield',
    name: 'Airfield',
    description: 'Base for aircraft operations. Enables air superiority and ground support.',
    type: 'production',
    category: 'airfield',
    stats: {
      hp: 1000,
      armor: 25,
      sightRange: 350,
      buildTime: 80
    },
    cost: {
      manpower: 120,
      fuel: 150,
      ammo: 60,
      steel: 120
    },
    abilities: [
      {
        id: 'scramble',
        name: 'Emergency Scramble',
        description: 'Instantly deploy fighter squadron',
        cooldown: 150,
        effect: { type: 'spawn', units: ['fighter'], count: 2 }
      },
      {
        id: 'runway_repair',
        name: 'Runway Repair',
        description: 'Heal all aircraft on ground',
        cooldown: 90,
        effect: { type: 'heal', target: 'aircraft', amount: 100 }
      }
    ],
    techRequirements: ['aviation_technology'],
    producesUnits: ['p51_mustang', 'me262', 'b17_flying_fortress', 'stuka'],
    tags: ['production', 'aircraft', 'air_power']
  },

  // ========== RESOURCE BUILDINGS ==========
  supply_depot: {
    id: 'supply_depot',
    name: 'Supply Depot',
    description: 'Stores and distributes ammunition and supplies to frontline units.',
    type: 'support',
    category: 'supply_depot',
    stats: {
      hp: 600,
      armor: 15,
      sightRange: 180,
      buildTime: 35
    },
    cost: {
      manpower: 80,
      fuel: 20,
      ammo: 30,
      steel: 50
    },
    production: {
      resourceType: 'ammo',
      productionRate: 40
    },
    abilities: [
      {
        id: 'supply_range',
        name: 'Supply Range',
        description: 'Resupply units within large radius',
        cooldown: 0,
        effect: { type: 'passive_resupply', radius: 200, rate: 5 }
      }
    ],
    techRequirements: [],
    tags: ['resource', 'ammo', 'logistics']
  },

  refinery: {
    id: 'refinery',
    name: 'Oil Refinery',
    description: 'Processes crude oil into fuel for vehicles and aircraft.',
    type: 'support',
    category: 'refinery',
    stats: {
      hp: 700,
      armor: 18,
      sightRange: 150,
      buildTime: 50
    },
    cost: {
      manpower: 100,
      fuel: 50,
      ammo: 20,
      steel: 80
    },
    production: {
      resourceType: 'fuel',
      productionRate: 50
    },
    abilities: [],
    techRequirements: ['petroleum_industry'],
    tags: ['resource', 'fuel', 'industrial']
  },

  steel_mill: {
    id: 'steel_mill',
    name: 'Steel Mill',
    description: 'Produces steel from iron ore. Essential for vehicle production.',
    type: 'support',
    category: 'refinery',
    stats: {
      hp: 750,
      armor: 20,
      sightRange: 150,
      buildTime: 55
    },
    cost: {
      manpower: 110,
      fuel: 60,
      ammo: 25,
      steel: 100
    },
    production: {
      resourceType: 'steel',
      productionRate: 35
    },
    abilities: [],
    techRequirements: ['heavy_industry'],
    tags: ['resource', 'steel', 'industrial']
  },

  // ========== DEFENSIVE BUILDINGS ==========
  radar_station: {
    id: 'radar_station',
    name: 'Radar Station',
    description: 'Detects enemy aircraft and provides early warning.',
    type: 'defense',
    category: 'radar',
    stats: {
      hp: 500,
      armor: 12,
      sightRange: 600,
      buildTime: 40
    },
    cost: {
      manpower: 70,
      fuel: 40,
      ammo: 15,
      steel: 60
    },
    abilities: [
      {
        id: 'air_detection',
        name: 'Air Detection',
        description: 'Reveal all enemy aircraft in large radius',
        cooldown: 0,
        effect: { type: 'reveal', targetType: 'aircraft', radius: 600 }
      },
      {
        id: 'ground_surveillance',
        name: 'Ground Surveillance',
        description: 'Detect stealth units',
        cooldown: 0,
        effect: { type: 'counter_stealth', radius: 400 }
      }
    ],
    techRequirements: ['radar_technology'],
    tags: ['defense', 'detection', 'support']
  },

  aa_emplacement: {
    id: 'aa_emplacement',
    name: 'Anti-Air Emplacement',
    description: 'Heavy AA guns defend against enemy aircraft.',
    type: 'defense',
    category: 'aa_emplacement',
    stats: {
      hp: 450,
      armor: 25,
      sightRange: 400,
      buildTime: 35,
      garrisonCapacity: 4
    },
    cost: {
      manpower: 60,
      fuel: 30,
      ammo: 50,
      steel: 55
    },
    abilities: [
      {
        id: 'flak_barrage',
        name: 'Flak Barrage',
        description: 'Area denial against aircraft',
        cooldown: 15,
        effect: { type: 'aoe_aa', radius: 80, damage: 60 }
      }
    ],
    techRequirements: ['aa_guns'],
    tags: ['defense', 'anti_air', 'static']
  },

  artillery_emplacement: {
    id: 'artillery_emplacement',
    name: 'Artillery Emplacement',
    description: 'Fixed artillery position for long-range bombardment.',
    type: 'defense',
    category: 'artillery_emplacement',
    stats: {
      hp: 550,
      armor: 30,
      sightRange: 300,
      buildTime: 50,
      garrisonCapacity: 6
    },
    cost: {
      manpower: 80,
      fuel: 40,
      ammo: 80,
      steel: 70
    },
    abilities: [
      {
        id: 'long_range_bombardment',
        name: 'Long Range Bombardment',
        description: 'Fire at extreme range with high explosive shells',
        cooldown: 20,
        effect: { type: 'artillery_strike', range: 700, radius: 60, damage: 120 }
      }
    ],
    techRequirements: ['coastal_defense'],
    tags: ['defense', 'artillery', 'static', 'long_range']
  },

  bunker: {
    id: 'bunker',
    name: 'Concrete Bunker',
    description: 'Heavily fortified position. Can garrison infantry for defense.',
    type: 'defense',
    category: 'bunker',
    stats: {
      hp: 1500,
      armor: 80,
      sightRange: 250,
      buildTime: 60,
      garrisonCapacity: 10
    },
    cost: {
      manpower: 100,
      fuel: 30,
      ammo: 40,
      steel: 120
    },
    abilities: [
      {
        id: 'fortified_position',
        name: 'Fortified Position',
        description: 'Garrisoned units gain +100% armor',
        cooldown: 0,
        effect: { type: 'garrison_bonus', stat: 'armor', value: 1.0 }
      }
    ],
    techRequirements: ['fortification_engineering'],
    tags: ['defense', 'fortification', 'garrison']
  },

  trench: {
    id: 'trench',
    name: 'Trench Line',
    description: 'Defensive earthworks providing cover for infantry.',
    type: 'defense',
    category: 'trench',
    stats: {
      hp: 400,
      armor: 10,
      sightRange: 150,
      buildTime: 20,
      garrisonCapacity: 8
    },
    cost: {
      manpower: 40,
      fuel: 5,
      ammo: 10,
      steel: 15
    },
    abilities: [
      {
        id: 'cover',
        name: 'Cover',
        description: 'Garrisoned units take -50% damage',
        cooldown: 0,
        effect: { type: 'garrison_damage_reduction', value: 0.5 }
      }
    ],
    techRequirements: [],
    tags: ['defense', 'fortification', 'garrison', 'cheap']
  },

  // ========== RESEARCH BUILDINGS ==========
  research_lab: {
    id: 'research_lab',
    name: 'Research Laboratory',
    description: 'Advanced facility for developing new technologies and upgrades.',
    type: 'research',
    category: 'research_lab',
    stats: {
      hp: 600,
      armor: 15,
      sightRange: 200,
      buildTime: 65
    },
    cost: {
      manpower: 90,
      fuel: 50,
      ammo: 30,
      steel: 80
    },
    abilities: [
      {
        id: 'research_boost',
        name: 'Research Boost',
        description: '+25% research speed',
        cooldown: 0,
        effect: { type: 'passive', stat: 'research_speed', value: 0.25 }
      },
      {
        id: 'breakthrough',
        name: 'Scientific Breakthrough',
        description: 'Instantly complete current research tier',
        cooldown: 300,
        effect: { type: 'instant_research', tiers: 1 }
      }
    ],
    techRequirements: ['scientific_method'],
    tags: ['research', 'technology', 'upgrades']
  },

  // ========== FACTION-SPECIFIC BUILDINGS ==========
  airborne_command: {
    id: 'airborne_command',
    name: 'Airborne Command Post',
    description: 'Allies special facility for paratrooper operations.',
    type: 'production',
    category: 'barracks',
    stats: {
      hp: 700,
      armor: 18,
      sightRange: 220,
      buildTime: 50
    },
    cost: {
      manpower: 90,
      fuel: 40,
      ammo: 30,
      steel: 55
    },
    abilities: [
      {
        id: 'paradrop',
        name: 'Paratrooper Drop',
        description: 'Deploy paratroopers behind enemy lines',
        cooldown: 120,
        effect: { type: 'paradrop', units: ['paratrooper'], count: 8, maxDistance: 500 }
      }
    ],
    techRequirements: ['airborne_doctrine'],
    producesUnits: ['paratrooper'],
    factionExclusive: ['allies'],
    tags: ['production', 'infantry', 'allies', 'special']
  },

  heavy_tank_factory: {
    id: 'heavy_tank_factory',
    name: 'Heavy Tank Factory',
    description: 'Axis specialized facility for producing heavy and super-heavy tanks.',
    type: 'production',
    category: 'vehicle_factory',
    stats: {
      hp: 1400,
      armor: 45,
      sightRange: 260,
      buildTime: 90
    },
    cost: {
      manpower: 180,
      fuel: 100,
      ammo: 50,
      steel: 200
    },
    abilities: [
      {
        id: 'overengineered',
        name: 'Overengineered Quality',
        description: 'Produced heavy tanks have +10% HP',
        cooldown: 0,
        effect: { type: 'production_bonus', targetType: 'heavy_tank', stat: 'hp', value: 0.1 }
      }
    ],
    techRequirements: ['heavy_armor_doctrine', 'precision_engineering'],
    producesUnits: ['tiger_i', 'panther', 'landkreuzer'],
    factionExclusive: ['axis'],
    tags: ['production', 'vehicles', 'axis', 'heavy_armor']
  },

  underground_bunker: {
    id: 'underground_bunker',
    name: 'Underground Bunker',
    description: 'Resistance hidden facility. Cannot be detected by normal means.',
    type: 'defense',
    category: 'bunker',
    stats: {
      hp: 1200,
      armor: 60,
      sightRange: 200,
      buildTime: 70
    },
    cost: {
      manpower: 80,
      fuel: 20,
      ammo: 35,
      steel: 90
    },
    abilities: [
      {
        id: 'hidden',
        name: 'Hidden Facility',
        description: 'Invisible until attacking or revealed',
        cooldown: 0,
        effect: { type: 'stealth', breakOnAttack: true }
      }
    ],
    techRequirements: ['underground_network'],
    factionExclusive: ['resistance'],
    tags: ['defense', 'resistance', 'stealth']
  },

  sabotage_camp: {
    id: 'sabotage_camp',
    name: 'Sabotage Camp',
    description: 'Resistance training ground for sabotage and guerrilla operations.',
    type: 'production',
    category: 'barracks',
    stats: {
      hp: 500,
      armor: 10,
      sightRange: 180,
      buildTime: 30
    },
    cost: {
      manpower: 50,
      fuel: 15,
      ammo: 25,
      steel: 30
    },
    abilities: [
      {
        id: 'sabotage',
        name: 'Sabotage Operation',
        description: 'Disable enemy building for 30 seconds',
        cooldown: 180,
        effect: { type: 'disable_building', duration: 30, maxRange: 300 }
      }
    ],
    techRequirements: ['guerrilla_tactics'],
    producesUnits: ['partisan', 'maquis', 'guerrilla_fighter'],
    factionExclusive: ['resistance'],
    tags: ['production', 'infantry', 'resistance', 'special']
  },

  advanced_research_lab: {
    id: 'advanced_research_lab',
    name: 'Advanced Research Lab',
    description: 'Experimental facility for cutting-edge weapons development.',
    type: 'research',
    category: 'research_lab',
    stats: {
      hp: 700,
      armor: 20,
      sightRange: 220,
      buildTime: 85
    },
    cost: {
      manpower: 120,
      fuel: 80,
      ammo: 50,
      steel: 130
    },
    abilities: [
      {
        id: 'quantum_leap',
        name: 'Quantum Leap',
        description: 'Unlock experimental tier technologies',
        cooldown: 0,
        effect: { type: 'unlock_tier', tier: 'experimental' }
      }
    ],
    techRequirements: ['advanced_science', 'wunderwaffe'],
    factionExclusive: ['experimental'],
    tags: ['research', 'experimental', 'advanced']
  },

  prototype_factory: {
    id: 'prototype_factory',
    name: 'Prototype Factory',
    description: 'Experimental production facility for prototype weapons.',
    type: 'production',
    category: 'vehicle_factory',
    stats: {
      hp: 1100,
      armor: 30,
      sightRange: 240,
      buildTime: 75
    },
    cost: {
      manpower: 140,
      fuel: 90,
      ammo: 60,
      steel: 160
    },
    abilities: [
      {
        id: 'rapid_prototype',
        name: 'Rapid Prototyping',
        description: '-50% build time for experimental units',
        cooldown: 0,
        effect: { type: 'production_speed', targetType: 'experimental', value: 0.5 }
      }
    ],
    techRequirements: ['prototype_program'],
    producesUnits: ['landkreuzer', 'ho229', 'atomic_artillery', 'rocket_tank'],
    factionExclusive: ['experimental'],
    tags: ['production', 'experimental', 'prototypes']
  }
};

export function getBuilding(buildingId: string): Building | undefined {
  return BUILDINGS[buildingId];
}

export function getAllBuildings(): Building[] {
  return Object.values(BUILDINGS);
}

export function getBuildingsByType(type: BuildingType): Building[] {
  return Object.values(BUILDINGS).filter(b => b.type === type);
}

export function getBuildingsByFaction(factionId: string): Building[] {
  return Object.values(BUILDINGS).filter(b => 
    !b.factionExclusive || b.factionExclusive.includes(factionId)
  );
}
